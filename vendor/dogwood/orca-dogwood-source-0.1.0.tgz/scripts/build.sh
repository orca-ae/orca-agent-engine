#!/bin/sh
set -eu
root=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$root"
task_cargo_root=${CARGO_HOME:-"$HOME/.cargo"}
export RUSTFLAGS="${RUSTFLAGS:-} --remap-path-prefix=$root=orca-dogwood --remap-path-prefix=$task_cargo_root=cargo-registry"
export CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_PROFILE_RELEASE_DEBUG=0 CARGO_INCREMENTAL=0
bindgen=${WASM_BINDGEN:-"$root/tools/bin/wasm-bindgen"}
task_node=${NODE_BINARY:-node}
if [ "$("$bindgen" --version)" != "wasm-bindgen 0.2.130" ]; then
  echo 'Build requires the lock-matched wasm-bindgen 0.2.130 CLI.' >&2
  exit 1
fi
case ${1:-production} in
  conformance)
    cargo +1.94.0 build --locked --offline --bin orca-dogwood-json --features conformance
    cargo +1.94.0 build --locked --offline --lib --target wasm32-unknown-unknown --features conformance
    mkdir -p dist/conformance
    cp target/debug/orca-dogwood-json dist/conformance/orca-dogwood-json
    "$bindgen" --target nodejs --out-dir dist/conformance/wasm --out-name orca_dogwood target/wasm32-unknown-unknown/debug/orca_dogwood.wasm
    ;;
  production)
    cargo +1.94.0 build --locked --offline --lib --target wasm32-unknown-unknown --no-default-features
    cargo +1.94.0 build --locked --offline -p orca-dogwood-clock --release
    "$bindgen" --target nodejs --out-dir package/wasm --out-name orca_dogwood target/wasm32-unknown-unknown/debug/orca_dogwood.wasm
    "$task_node" scripts/stage.mjs
    ;;
  *) echo 'usage: scripts/build.sh production|conformance' >&2; exit 1 ;;
esac
