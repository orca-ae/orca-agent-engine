#!/usr/bin/env python3
"""Verify vendored source is the pinned crate plus only the recorded patch."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tarfile
import tempfile

root = Path(__file__).resolve().parent.parent
provenance = json.loads((root / 'UPSTREAM.json').read_text())
archive = Path(sys.argv[1])
assert hashlib.sha256(archive.read_bytes()).hexdigest() == provenance['crate_sha256']
patch = root / provenance['compatibility_patch']
assert hashlib.sha256(patch.read_bytes()).hexdigest() == provenance['compatibility_patch_sha256']
with tempfile.TemporaryDirectory(prefix='orca-dogwood-upstream-') as temporary:
    expected = Path(temporary)
    with tarfile.open(archive, 'r:gz') as source:
        for item in source:
            if not item.isfile():
                continue
            name = Path(item.name)
            assert name.parts[0] == 'dogwood-language-1.1.0'
            relative = Path(*name.parts[1:])
            assert not relative.is_absolute() and '..' not in relative.parts
            target = expected / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(source.extractfile(item).read())
    subprocess.run(['patch', '-p1', '-i', str(patch)], cwd=expected, check=True, capture_output=True)
    def files(directory):
        return {str(path.relative_to(directory)): hashlib.sha256(path.read_bytes()).hexdigest()
                for path in directory.rglob('*') if path.is_file()}
    assert files(expected) == files(root / 'vendor/dogwood-language'), 'vendored source differs from archive plus recorded patch'
print(json.dumps({'upstream': provenance['version'], 'archive_sha256': provenance['crate_sha256'], 'vendored_source': 'exact archive plus recorded patch'}))
