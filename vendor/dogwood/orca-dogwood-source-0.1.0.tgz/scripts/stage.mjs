#!/usr/bin/env node
import { readFileSync, writeFileSync, mkdirSync, copyFileSync, readdirSync } from 'node:fs';
import { resolve, join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const hash = path => createHash('sha256').update(readFileSync(path)).digest('hex');
const platform = `${process.platform}-${process.arch}`;
const helperPath = `bin/${platform}/orca-dogwood-clock`;
mkdirSync(join(root, 'package', dirname(helperPath)), { recursive: true });
copyFileSync(join(root, 'target/release/orca-dogwood-clock'), join(root, 'package', helperPath));
const sources = [];
function walk(directory) {
  for (const entry of readdirSync(join(root, directory), { withFileTypes: true })) {
    const path = join(directory, entry.name);
    if (entry.isDirectory()) walk(path);
    else sources.push({ path: path.replaceAll('\\', '/'), sha256: hash(join(root, path)) });
  }
}
for (const directory of ['src', 'schemas', 'clock-helper/src', 'scripts', 'tests']) walk(directory);
for (const path of ['Cargo.toml', 'Cargo.lock', 'clock-helper/Cargo.toml', 'UPSTREAM.json', 'docs/upstream-rust194.diff', 'package/index.cjs', 'package/index.d.ts', 'package/package.json', 'API.md']) sources.push({ path, sha256: hash(join(root, path)) });
sources.sort((a, b) => a.path.localeCompare(b.path, 'en'));
const vendorFiles = [];
function vendorWalk(directory) {
  for (const entry of readdirSync(join(root, directory), { withFileTypes: true })) {
    const path = join(directory, entry.name);
    if (entry.isDirectory()) vendorWalk(path);
    else vendorFiles.push({path:path.replaceAll('\\', '/'),sha256:hash(join(root,path))});
  }
}
vendorWalk('vendor/dogwood-language');
vendorFiles.sort((a,b) => a.path.localeCompare(b.path,'en'));
let sourceCommit = null;
try { sourceCommit = execFileSync('git', ['rev-parse', 'HEAD'], {cwd:root,encoding:'utf8',stdio:['ignore','pipe','ignore']}).trim(); } catch {}
const provenance = {
  core: { name: 'orca-dogwood', version: '0.1.0', rust: '1.94.0', source_commit: sourceCommit, source_tree_sha256: createHash('sha256').update(JSON.stringify(sources)).digest('hex'), sources },
  upstream: JSON.parse(readFileSync(join(root, 'UPSTREAM.json'), 'utf8')),
  vendor_tree_sha256: createHash('sha256').update(JSON.stringify(vendorFiles)).digest('hex'),
  wasm_sha256: hash(join(root, 'package/wasm/orca_dogwood_bg.wasm')),
  clock_helpers: { [platform]: { path: helperPath, sha256: hash(join(root, 'package', helperPath)) } },
};
writeFileSync(join(root, 'package/provenance.json'), `${JSON.stringify(provenance, null, 2)}\n`);
if (process.argv.includes('--metadata-only')) {
  console.log(`staged package metadata for ${platform}`);
  process.exit(0);
}
mkdirSync(join(root, 'dist'), { recursive: true });
execFileSync('npm', ['--cache', join(root, 'target/npm-cache'), 'pack', '--offline', './package', '--pack-destination', './dist'], { cwd: root, stdio: 'inherit' });
const archive = 'dist/orca-dogwood-source-0.1.0.tgz';
execFileSync('tar', ['-czf', archive, '--exclude=./target', '--exclude=./tools', '--exclude=./dist', '--exclude=./.git', '--exclude=./package/wasm', '--exclude=./package/bin', '.'], { cwd: root });
const artifacts = ['dist/runorca-dogwood-0.1.0.tgz', archive].map(path => ({ path, sha256: hash(join(root, path)) }));
writeFileSync(join(root, 'dist/artifacts.json'), `${JSON.stringify({ ...provenance, artifacts }, null, 2)}\n`);
console.log(JSON.stringify({ source_tree_sha256: provenance.core.source_tree_sha256, artifacts }, null, 2));
