'use strict';
const assert = require('node:assert/strict');
const { spawnSync } = require('node:child_process');
const { resolve } = require('node:path');
const core = require(resolve(process.argv[3] ?? 'package'));
const native = resolve(process.argv[2] ?? 'target/debug/orca-dogwood-json');
let checked = 0;
function check(input) {
  const result = spawnSync(native, [], { input: `${JSON.stringify(input)}\n`, encoding: 'utf8', maxBuffer: 16777216 });
  assert.equal(result.status, 0, result.stderr);
  const actual = core.execute(input);
  assert.deepEqual(actual, JSON.parse(result.stdout), `${input.op} native/WASM mismatch`);
  checked++;
  return actual;
}
const baseline = '@id("baseline") permit(principal,action,resource);';
const ask = `${baseline}\n@id("push") @ask @description("Push requires approval") forbid(principal,action == Orca::Action::"bash",resource) when {context.input.command like "git push*"} unless temporal {formerly within 1h Orca::Action::"bash"::approval{askedBy:"push",result:"allow"}};`;
const call = {action:'bash',principal:{type:'Developer',id:'usr-1'},resource:{type:'Harness',id:'codex'},request_id:'tool-1',session_id:'s-1',input:{command:'git push origin main'}};
const evaluate = (rule, now_ms=2000, history=[], candidate=call, guardrail_id='grd-1') => check({op:'evaluate',rule,now_ms,history,call:candidate,guardrail_id});
check({op:'schemas'});
check({op:'canonical_tool',harness:'codex',tool:'exec_command'});
check({op:'canonical_tool',harness:'claude_code',tool:'mcp__alias__create_issue',server_url:'https://mcp.example/jira',manifests:[{server:'jira',url:'https://mcp.example/jira',tools:[]} ]});
assert.equal(check({op:'validate',rule:{kind:'dogwood',policy:baseline}}).valid,true);
assert.equal(check({op:'validate',rule:{policy:'@ask permit(principal,action,resource);'}}).valid,false);
assert.equal(evaluate({policy:baseline}).verdict,'allow');
assert.equal(evaluate({policy:'@id("deny") forbid(principal,action,resource);'}).verdict,'deny');
assert.equal(evaluate({policy:baseline,appliesTo:'mcp_tools'}).verdict,'abstain');
const rule = {policy:ask};
const initial = evaluate(rule);
assert.equal(initial.verdict,'ask'); assert.ok(Number.isSafeInteger(initial.valid_before));
const approved = check({op:'finalize_outcome',rule,guardrail_id:'grd-1',call,now_ms:1001,outcome:'approved',asking_rule_ids:['push'],approver:'admin'});
assert.equal(approved.errors.length,0);
const allowed = evaluate(rule,2000,approved.events); assert.equal(allowed.verdict,'allow'); assert.equal(allowed.valid_before,3601001);
assert.equal(evaluate(rule,2000,approved.events,call,'another-guardrail').verdict,'ask');
assert.equal(evaluate(rule,3601000,approved.events).verdict,'allow');
assert.equal(evaluate(rule,3601002,approved.events).verdict,'ask');
const unsafeDeadline = evaluate(rule,Number.MAX_SAFE_INTEGER-1);
assert.equal(unsafeDeadline.verdict,'deny'); assert.ok(unsafeDeadline.errors.length); assert.equal(unsafeDeadline.valid_before,null);
const counter = {policy:`${baseline}\n@id("one") forbid(principal,action == Orca::Action::"bash",resource) when temporal {count_within(1h,Orca::Action::"bash"::request{}) > 1};`};
const first = evaluate(counter); assert.equal(first.verdict,'allow');
assert.equal(evaluate(counter,2001,first.events.deny).verdict,'allow');
assert.equal(evaluate(counter,2001,first.events.allow).verdict,'deny');
const interrupted = check({op:'finalize_outcome',rule:counter,guardrail_id:'grd-1',call,now_ms:2001,outcome:'interrupted'});
assert.equal(evaluate(counter,2002,[...first.events.allow,...interrupted.events]).verdict,'deny');
assert.equal(evaluate(counter,2001,first.events.allow,{...call,session_id:'s-2'}).verdict,'allow');
assert.equal(evaluate({...counter,history:'principal'},2001,first.events.allow,{...call,session_id:'s-2'}).verdict,'deny');
const mcpRule = {kind:'dogwood',policy:baseline,appliesTo:'mcp_tools',mcpManifests:[{server:'jira',url:'https://mcp.example/jira',tools:[{name:'create_issue',inputSchema:{type:'object',properties:{project:{type:'string'}},required:['project']},outputSchema:{type:'object',properties:{key:{type:'string'}},required:['key']}}]}]};
const mcpCall = {...call,action:'mcp__jira__create_issue',input:{project:'SEC'},mcp:{server:'jira',server_host:'mcp.example'}};
assert.equal(check({op:'validate',rule:mcpRule}).valid,true);
assert.equal(evaluate(mcpRule,2000,[],mcpCall).verdict,'allow');
const directCall = {...mcpCall,
  principal:{type:'Caller',id:'caller-1',attributes:{subject:'api_key:key-1'},parents:[{type:'Workspace',id:'wk-1'}]},
  resource:{type:'Gateway',id:'gateway-1',parents:[{type:'Workspace',id:'wk-1'}]},
  subject:{kind:'api_key',id:'key-1'}};
const directBase = evaluate(mcpRule,2000,[],directCall);
assert.equal(directBase.verdict,'allow'); assert.deepEqual(directBase.errors,[]);
const directRule = {...mcpRule,policy:'@id("bound") permit(principal == Orca::Caller::"caller-1", action == Orca::Action::"mcp__jira__create_issue", resource == Orca::Gateway::"gateway-1") when {principal in Orca::Workspace::"wk-1" && resource in Orca::Workspace::"wk-1" && principal.subject == "api_key:key-1" && context has subject && context.subject.kind == "api_key" && context.subject.id == "key-1"};'};
assert.equal(check({op:'validate',rule:directRule}).valid,true);
assert.equal(evaluate(directRule,2000,[],directCall).verdict,'allow');
for (const role of ['principal','resource']) {
  assert.equal(evaluate(directRule,2000,[],{...directCall,[role]:{...directCall[role],parents:[{type:'Workspace',id:'wk-other'}]}}).verdict,'deny');
}
assert.equal(evaluate(directRule,2000,[],{...directCall,principal:{...directCall.principal,attributes:{subject:'api_key:other'}}}).verdict,'deny');
const missingSubject = evaluate(directRule,2000,[],{...directCall,principal:{...directCall.principal,attributes:{}}});
assert.equal(missingSubject.verdict,'deny'); assert.ok(missingSubject.errors.length);
assert.equal(evaluate(directRule,2000,[],{...directCall,subject:{kind:'api_key',id:'other'}}).verdict,'deny');
const response = check({op:'finalize_outcome',rule:mcpRule,guardrail_id:'grd-1',call:mcpCall,now_ms:2001,outcome:'response',output:{structuredContent:{key:'SEC-1',secret:'excluded'}}});
assert.deepEqual(response.events[0].output,{key:'SEC-1'});
const secondProjection = structuredClone(mcpRule);
secondProjection.mcpManifests[0].tools[0].outputSchema = {type:'object',properties:{state:{type:'string'}},required:['state']};
const secondDirect = evaluate(secondProjection,2000,[],directCall);
assert.equal(secondDirect.verdict,'allow');
const reservation = check({op:'merge_events',events:[...directBase.events.allow,...secondDirect.events.allow]});
assert.deepEqual(reservation.errors,[]); assert.equal(reservation.events.length,1); assert.equal(reservation.events[0].kind,'request');
const response2 = check({op:'finalize_outcome',rule:secondProjection,guardrail_id:'grd-2',call:mcpCall,now_ms:2001,outcome:'response',output:{structuredContent:{key:'SEC-1',state:'open'}}});
assert.deepEqual(response2.errors,[]);
const projected = check({op:'merge_events',events:[...response.events,...response2.events]});
assert.deepEqual(projected.errors,[]); assert.equal(projected.events.length,1); assert.deepEqual(projected.events[0].output,{key:'SEC-1',state:'open'});
for (const conflict of ['different',{nested:true}]) {
  const result = check({op:'merge_events',events:[response.events[0],{...response.events[0],output:{key:conflict}}]});
  assert.deepEqual(result.events,[]); assert.ok(result.errors.length);
}
const identityConflict = check({op:'merge_events',events:[...directBase.events.allow,{...directBase.events.allow[0],timestamp_ms:2001}]});
assert.deepEqual(identityConflict.events,[]); assert.ok(identityConflict.errors.length);
const boundedUnion = check({op:'merge_events',events:[
  {...response.events[0],input:{payload:{a:'x'.repeat(2500)}},output:{payload:{a:'x'.repeat(2500)}}},
  {...response.events[0],input:{payload:{b:'y'.repeat(2500)}},output:{payload:{b:'y'.repeat(2500)}}}
]});
assert.deepEqual(boundedUnion.errors,[]);
for (const field of ['input','output']) {assert.ok(boundedUnion.events[0][field].payload.size>4096); assert.equal(boundedUnion.events[0][field].payload.sha256.length,64);}
const approval = approved.events.find(event=>event.kind==='approval');
const approvals = check({op:'merge_events',events:[approval,{...approval,guardrail_id:'grd-2'},{...approval,asked_by:'other-ask'},approval]});
assert.deepEqual(approvals.errors,[]); assert.equal(approvals.events.length,3);
const approvalOrder = check({op:'merge_events',events:[...approved.events,{...approval,guardrail_id:'grd-2'},...approved.events]});
assert.deepEqual(approvalOrder.errors,[]); assert.deepEqual(approvalOrder.events.map(event=>event.kind),['approval','approval','request']);
const bounded = check({op:'finalize_outcome',rule:{policy:baseline},guardrail_id:'grd-1',call:{...call,input:{command:'x'.repeat(5000)}},now_ms:2001,outcome:'denied'});
assert.equal(bounded.events[0].input.command.size,5002);
assert.ok(bounded.events[0].input.command.sha256);
const a = core.readClock(); const b = core.readClock();
assert.equal(a.epoch_id,b.epoch_id); assert.equal(a.boot_id,b.boot_id); assert.ok(b.monotonic_ms >= a.monotonic_ms);
console.log(JSON.stringify({native_wasm_operations:checked,clock_helper:'passed',node:process.version}));
