# Focused local verification

Toolchain: Rust 1.94.0; wasm-bindgen CLI 0.2.130; Node v22.23.1.
Host: Darwin arm64. Publication, production deployment and remote repository
creation were not performed.

- `cargo +1.94.0 test -p orca-dogwood --test contract --locked --offline`:
  15 passed, covering actual upstream allow/default-deny/errors, second-pass
  ask, scoped approvals, session/principal pins, committed-request counting,
  interruption, MCP generation/output projection/decimal fields, canonical
  tool isolation, annotation/resource limits, edits and exact temporal bounds.
  Direct Caller/Gateway tests first reproduced actual Cedar entity-conformance
  failure, then passed after only their Workspace membership declarations were
  added. Wrong Caller/Gateway workspace, changed principal/context subject and
  missing required Caller.subject still deny through the real core.
- `cargo +1.94.0 test -p orca-dogwood --test merge --locked --offline`:
  6 passed, including actual two-policy MCP projection union, one request
  reservation, scalar/type/authority metadata conflicts, separate scoped
  approvals, approval-before-request order and 4 KiB bounds after input/output
  record projection union.
- `cargo +1.94.0 clippy -p orca-dogwood -p orca-dogwood-clock --all-targets
  --all-features --locked --offline -- -D warnings`: passed.
- `cargo +1.94.0 fmt -p orca-dogwood -p orca-dogwood-clock -- --check`: passed.
  Vendor formatting is intentionally preserved.
- `scripts/build.sh conformance` then Node 22 `scripts/corpus.cjs`: actual native
  and actual WASM results identical, 577 temporal cases / 1061 traces,
  261 parse-or-validation rejections, 154 macro cases / 254 traces, zero failures.
- Node 22 `scripts/equivalence.cjs` against the unpacked npm package and the
  native driver: 44 operations identical, including actual Orca verdict/event
  assertions; native clock helper also passed.
- Node 22 `scripts/clock-contract.cjs` against the unpacked package: samples
  monotonic in one process; process epoch changes on restart; missing helper
  and checksum corruption fail closed. The actual Darwin boot identity query
  needed read-only host access outside the execution sandbox.
- `python3 scripts/verify-upstream.py <pinned-crate-archive>`: complete vendor
  tree exactly equals crate SHA-256 from `UPSTREAM.json` plus the recorded
  three-guard Rust 1.94 compatibility patch.
- Production WASM/helper byte scans: zero builder home or temporary directory
  path prefixes. Source/docs contain no builder-specific absolute paths.

The native upstream corpus and WASM corpus execute actual upstream semantics;
there is no replacement interpreter or copied expected-verdict engine. The Orca
checks execute the shared wrapper and compare real builds. Production packaging
omits the corpus operation and contains no clock calls within core semantics.

Remaining consumer/platform gates: real Registry transaction and history
completeness, authenticated caller/approval authority, writer/epoch/bundle
fences, real sleep/reboot testing, Linux helper builds and runtime checks, and
the combined Registry advance / local elapsed-underestimate qualification.
Unknown qualification stays closed. This core does not claim those operational
gates have passed.
