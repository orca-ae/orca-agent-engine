# OIP-029 shared core acceptance plan

Status: Implemented and verified locally. No publication/deployment.

1. Verify the exact upstream 1.1.0 compiler requirements using Rust 1.94.0.
   Document any minimal vendored compatibility adaptation and provenance.
2. Establish the versioned JSON contract, fixed Orca schemas, canonical tools,
   MCP schema generation, limits and annotations with failing focused tests.
3. Use upstream parse/lower/validate/authorize for all policy decisions. Rebuild
   from caller-provided history for each candidate. Filter approvals by the
   guardrail identity and use the second evaluation after removing @ask rules.
4. Compute a conservative exclusive temporal validity boundary from real parsed
   temporal AST and retained-event aging. An unsafe/unknown interval errors.
5. Bind the same entry point to native CLI and wasm-bindgen Node. Run Orca and
   upstream corpus cases against both actual builds; compare JSON bytes.
6. Stage an immutable source/package artifact with source/version checksums for
   vendoring in Engine/Gateway, without sibling production path dependencies.

Acceptance covers stateless allow/deny/errors, ask/default-deny, annotation and
resource limits, session/principal pins, authorized-request counting, denied
attempt isolation, scoped approvals, edits over retained history, interrupted
outcomes, finite boundary equality and temporal valid_before.

Initial focused tests failed against the unimplemented core before production
logic was added. The exact-safe temporal deadline regression also failed with
an ask before its conservative-bound fix; it now denies with an explicit error.
Final commands and counts are in [VERIFICATION.md](VERIFICATION.md).

Direct-traffic acceptance subsequently exposed missing Cedar Workspace
membership declarations for Caller and Gateway. Two real-core tests first
failed entity conformance; the minimal schema fix preserves required
Caller.subject and is checked against mismatched workspace/subject inputs.

The shared pure merge_events operation was added after four failing focused
tests established the absent operation. It unions actual per-policy outcome
projections, deduplicates request reservations, rejects identity/scalar/type
conflicts, preserves approval scope and bounds field values after union.
An additional red regression established that every approval must precede the
single consuming request; merged groups now use that stable ordering.

No storage, network, clocks or deployments belong to the pure evaluator. The caller
owns authenticated identities, ordered complete history, authority time and
transaction/dispatch fences. Real Registry, sleep and platform acceptance are
outside this local-core verification. The separate clock-helper transport is
verified locally and still requires deployment clock qualification.
