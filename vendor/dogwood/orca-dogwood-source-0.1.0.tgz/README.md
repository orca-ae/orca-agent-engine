# Orca Dogwood shared core

This is the local OIP-029 implementation of `orca-dogwood` and
`@runorca/dogwood` 0.1.0. It wraps the exact upstream `dogwood-language` 1.1.0
parser, macro expander, validator, MCP schema generator and authorizer. No
replacement policy interpreter is implemented here. Publication is disabled.

See [API.md](API.md) for the shared JSON contract. Rust calls use `evaluate`,
`validate_rule`, `finalize_outcome`, `merge_events`, `canonical_tool` or `execute_json`; Node uses
the same operations through the compiled WASM module. History, identities,
authority time, approval authorization, storage and dispatch fences belong to
the authenticated caller. Observe/enforce folding belongs to the outer engine.

## Build and focused verification

Use Rust 1.94.0, Node 22 and a lock-matched `wasm-bindgen` 0.2.130 CLI. Install
the `wasm32-unknown-unknown` Rust target and put the CLI at
`tools/bin/wasm-bindgen`, or set `WASM_BINDGEN` to its executable. The lock file
and vendored upstream source are retained. Build commands use the local Cargo
cache in offline mode; populate it with `cargo +1.94.0 fetch --locked` first
when preparing a fresh builder.

```sh
cargo +1.94.0 test -p orca-dogwood --test contract --test merge --locked --offline
cargo +1.94.0 clippy -p orca-dogwood -p orca-dogwood-clock \
  --all-targets --all-features --locked --offline -- -D warnings
cargo +1.94.0 fmt -p orca-dogwood -p orca-dogwood-clock -- --check
scripts/build.sh conformance
node scripts/corpus.cjs
scripts/build.sh production
node scripts/equivalence.cjs dist/conformance/orca-dogwood-json package
node scripts/clock-contract.cjs package
```

The corpus command runs the complete pinned temporal and temporal-macro corpus
through actual native and actual WASM engines and compares results. It does not
substitute expected verdict files for either engine. Production packaging drops
the corpus operation. `scripts/equivalence.cjs` accepts an unpacked npm package
as its second positional path so the shipped artifact can be checked directly.

The build script strips local source/cache prefixes from binaries. Staging
produces `dist/runorca-dogwood-0.1.0.tgz`,
`dist/orca-dogwood-source-0.1.0.tgz` and `dist/artifacts.json`. The manifest
records core source, upstream archive, compatibility patch, WASM and platform
clock-helper SHA-256 digests. Vendor this source artifact inside each consumer;
production dependencies must not point at a sibling checkout. The source root
is an independent Cargo workspace; consuming workspaces should exclude its
vendor directory from their own member discovery.

## Native clock transport

The pure policy crate has no clock. The separate `clock-helper` binary and
Node `readClock()` supply a checksummed native elapsed-clock sample and boot /
process epoch. Linux uses BOOTTIME; Darwin uses its documented suspend-inclusive
MONOTONIC clock. Unsupported or unavailable helpers fail; no wall or JavaScript
clock fallback exists. A deployment must still qualify its combined Registry
excess-clock advance and local elapsed undercount bound before dispatch. A
helper binary alone does not establish that operational qualification.

This local artifact contains only the builder's host helper. Linux release CI
must build and package each supported Linux architecture as documented in
[clock-helper/README.md](clock-helper/README.md). Linux sleep/reboot, real
Registry transactions and rollout/dispatch acceptance remain consumer gates.

## Upstream compatibility and temporal boundaries

`UPSTREAM.json` pins upstream source commit and crate archive. Three if-let match
guards in upstream informalization require a compiler newer than 1.94; the
recorded patch only desugars those guards. The parser and interpreter remain
upstream code. License and notice files are retained.

An adapter changes upstream seconds to exact integer milliseconds without
changing its temporal operators. Exclusive `valid_before` is conservative: a
result must be recomputed at equality. It considers all retained-event window
and retention boundaries, including unmatched events. A temporal policy has a
finite safe bound or an error. Upstream windows are closed at their own equality;
a fresh evaluation there may remain valid for only the next millisecond. This
never extends the preceding decision's exclusive deadline.
