# Orca Dogwood JSON API v1

Native crate
`orca-dogwood` 0.1.0; Node package `@runorca/dogwood` 0.1.0; exact upstream
`dogwood-language` 1.1.0. No storage, clock or network is called by these APIs.
Native `execute_json` and Node `execute` accept an object with `op`; the Node
convenience functions below send the same JSON to the actual WASM core.

## Rules and calls

`Rule` is the stored Engine shape:

```ts
type Rule = {
  kind?: 'dogwood'; // accepted stored-kind discriminator
  policy: string;
  appliesTo?: 'all_tools' | 'mcp_tools'; // default all_tools
  history?: 'session' | 'principal';  // default session
  mcpManifests?: { server: string; url: string; tools: Record<string, unknown>[] }[];
};
type Entity = {
  type: 'Vault' | 'Unattributed' | 'Caller' | 'Developer' | 'Agent' | 'Gateway' | 'Harness' | 'Workspace';
  id: string;
  attributes?: Record<string, unknown>;
  parents?: { type: 'Workspace'; id: string }[];
};
type PolicyCall = {
  action: string; // canonical logical name or mcp__<manifest-server>__<tool>
  principal: Entity;
  resource: Entity;
  request_id: string;
  session_id: string;
  input: Record<string, unknown>;
  subject?: { kind: string; id: string };
  mcp?: { server: string; server_host: string };
};
type PolicyEvent = PolicyCall & {
  kind: 'request' | 'response' | 'error' | 'approval';
  timestamp_ms: number;
  guardrail_id?: string; // required for approval; never inferred from asked_by
  output?: Record<string, unknown>;
  error_type?: 'denied' | 'failed' | 'interrupted';
  result?: 'allow' | 'deny';
  asked_by?: string;
  approver?: string;
};
```

Times are exact safe integer UTC epoch milliseconds supplied by the caller.
The caller authenticates entities, supplies ordered complete retained history,
and owns Registry transaction/epoch/bundle/dispatch fences. History newer than
`now_ms`, nonmonotonic history, unknown mappings, malformed events or schema
failures are errors. Each guardrail sees all ordinary events but only its own
approvals. `interrupted` records unknown outcome and never removes an earlier
committed request reservation.

Direct MCP traffic uses `Caller` and `Gateway` entities, both permitting
`Workspace` parents in the Cedar schema. `Caller` requires a string `subject`
attribute. The authenticated caller binds that attribute, entity identities,
workspace parents and `call.subject`; the core never invents or authenticates
them. Policies may check membership and both subject representations. Built-in
logical actions retain the OIP's session/harness principal and resource roles;
generated MCP actions include direct caller/gateway roles.

## Validation

`validateRule(rule)` / `{op:'validate',rule}` returns:

```ts
{
  valid: boolean; errors: string[]; warnings: string[]; stateful: boolean;
  rule_ids: string[]; policy_hash: string; core_version: '0.1.0'; language_version: '1.1.0';
}
```

`policy_hash` is SHA-256 of normalized policy content (including defaulted
applicability/history/manifests). The core uses upstream parse, macro expansion,
MCP schema generation, lowering and validation, checks annotations and limits,
and refuses information providers. An empty/default-deny policy never becomes
an allow or abstention.

## Decision

`evaluate(request)` / `{op:'evaluate',...request}` takes:

```ts
{ guardrail_id: string; rule: Rule; now_ms: number; history: PolicyEvent[]; call: PolicyCall }
```

and returns:

```ts
{
  verdict: 'allow' | 'ask' | 'deny' | 'abstain';
  deciding_rules: { rule_id: string; description?: string; effect: 'permit'|'forbid'; ask: boolean }[];
  errors: string[];
  valid_before: number | null;
  policy_hash: string;
  events: { allow: PolicyEvent[]; deny: PolicyEvent[] };
}
```

`abstain` occurs only when `appliesTo:'mcp_tools'` excludes a built-in call.
Otherwise the core evaluates the retained history plus one uncommitted candidate
request through upstream. Any evaluation errors are returned and deny by default.
An `@ask` deny becomes ask only if a second actual upstream evaluation with ask
rules removed permits the same candidate. `valid_before` is conservative and
exclusive: equality is expired. Temporal policies always have a finite safe
bound or an explicit evaluation error; no matching history is not grounds for
`null`. A non-temporal result has `null`. Observe/enforce folding belongs to the
outer guardrail engine; the same core result supplies its raw evidence.

`events.allow` and `events.deny` are alternatives, not writes: the enforced
outcome chooses one after all other guardrails join the fold. The core records
an allowed request, or a denied error, never a denied request.

## Recording outcomes and approvals

`finalizeOutcome(request)` / `{op:'finalize_outcome',...request}` takes:

```ts
{
  guardrail_id: string; rule: Rule; call: PolicyCall; now_ms: number;
  outcome: 'allowed'|'denied'|'response'|'failed'|'interrupted'|'approved'|'refused';
  output?: unknown; // raw MCP result: structuredContent, or JSON text content
  asking_rule_ids?: string[]; approver?: string;
}
```

returns `{events: PolicyEvent[], errors:string[], policy_hash:string}`. Allowed
and denied produce the same alternatives as evaluation. Response extracts only
schema-declared MCP output fields; built-ins record no output. Failed and
interrupted produce their explicit error kind. Approved/refused produce one
approval per actual named ask rule plus request/error, respectively. The caller
must bind those confirmations to the current re-evaluated ask; this pure helper
does not authorize a confirmation. Oversized values are measured and hashed as their UTF-8 JSON serialization, and bounded using the OIP's
`{sha256,size,prefix}` representation. Unknown rule ids or invalid outcomes are
errors. A recorded result never reauthorizes a call or changes its request.

## Merging per-policy projections

`mergeEvents(events)` / `{op:'merge_events',events:PolicyEvent[]}` returns
`{events:PolicyEvent[],errors:string[]}`. Supply projections of one canonical
call outcome from all participating policies. Authenticated call identities,
parents, subject/MCP metadata and authoritative timestamp must match exactly.
Events group by `kind`, `error_type`, `guardrail_id` and `asked_by`; their other
immutable metadata must agree. Identical request projections produce one
request reservation. Distinct guardrail/asking-rule approvals stay distinct.

Input and output records are recursively unioned, preserving fields projected
by different policies. Equal scalar/array values are retained; unequal scalar,
array or type values are conflicts. Any conflict or malformed envelope returns
no events and an error. After union, each merged input/output field value is
bounded with the same 4 KiB `{sha256,size,prefix}` rule, including records whose
combined projections newly exceed that limit. All approval groups precede the
single request/error outcome so one-use approvals are consumed by that call;
groups otherwise retain first occurrence order. This helper does not choose an
outcome, authorize a call or write events.

## Schema and canonical vocabulary

`schemas()` / `{op:'schemas'}` returns
`{base_schema,event_schemas:{session,principal},language_version,core_version,limits}`.
The schemas include all built-in logical tools; MCP actions are generated per
rule from supplied tools/list manifests, including server/McpTool groups.

`canonicalTool(input)` / `{op:'canonical_tool',...input}` accepts
`{harness:'orca'|'claude_code'|'codex',tool:string,server_url?:string,manifests?:Rule['mcpManifests']}`
and returns `{action:string,is_mcp:boolean}`. URL-based MCP aliases use the
manifest's server, so a local server alias cannot rename a governed action.
Unknown harness/tools or ambiguous manifest URL matches return an error.

## Separate native clock helper

`readClock()` is an integration helper, separate from every pure core operation.
It spawns the packaged `orca-dogwood-clock` binary and verifies its checksum.
The helper uses a suspend-inclusive native clock (Linux BOOTTIME / Darwin
MONOTONIC) plus an OS boot identity. The Node wrapper adds an instance epoch
that changes on process restart. The result is
`{boot_id:string,epoch_id:string,monotonic_ms:number}` with exact safe integer
milliseconds. Missing/unsupported/corrupt helper or malformed clock output
throws; there is no JavaScript monotonic or wall-clock fallback. A qualified
error bound is still the caller deployment's responsibility. Source and Linux
build recipe live under `clock-helper/`; it is not linked into core decisions.
