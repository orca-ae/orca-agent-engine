use serde::{Deserialize, Serialize};
use serde_json::Value;
use std::collections::BTreeMap;

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct Rule {
    #[serde(default = "dogwood_kind")]
    pub kind: String,
    pub policy: String,
    #[serde(default)]
    pub applies_to: AppliesTo,
    #[serde(default)]
    pub history: HistoryScope,
    #[serde(default)]
    pub mcp_manifests: Vec<McpManifest>,
}
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum AppliesTo {
    #[default]
    AllTools,
    McpTools,
}
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum HistoryScope {
    #[default]
    Session,
    Principal,
}
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct McpManifest {
    pub server: String,
    pub url: String,
    pub tools: Vec<Value>,
}
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Entity {
    #[serde(rename = "type")]
    pub entity_type: String,
    pub id: String,
    #[serde(default)]
    pub attributes: BTreeMap<String, Value>,
    #[serde(default)]
    pub parents: Vec<EntityParent>,
}
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct EntityParent {
    #[serde(rename = "type")]
    pub entity_type: String,
    pub id: String,
}
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct PolicyCall {
    pub action: String,
    pub principal: Entity,
    pub resource: Entity,
    pub request_id: String,
    pub session_id: String,
    pub input: BTreeMap<String, Value>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub subject: Option<Value>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub mcp: Option<Value>,
}
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct PolicyEvent {
    #[serde(flatten)]
    pub call: PolicyCall,
    pub kind: EventKind,
    pub timestamp_ms: i64,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub guardrail_id: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub output: Option<Value>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub error_type: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub result: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub asked_by: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub approver: Option<String>,
}
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MergedEvents {
    pub events: Vec<PolicyEvent>,
    pub errors: Vec<String>,
}
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum EventKind {
    Request,
    Response,
    Error,
    Approval,
}
impl EventKind {
    pub fn as_str(self) -> &'static str {
        match self {
            Self::Request => "request",
            Self::Response => "response",
            Self::Error => "error",
            Self::Approval => "approval",
        }
    }
}
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct EvaluationRequest {
    pub guardrail_id: String,
    pub rule: Rule,
    pub now_ms: i64,
    pub history: Vec<PolicyEvent>,
    pub call: PolicyCall,
}
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum Outcome {
    Allowed,
    Denied,
    Response,
    Failed,
    Interrupted,
    Approved,
    Refused,
}
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct OutcomeRequest {
    pub guardrail_id: String,
    pub rule: Rule,
    pub call: PolicyCall,
    pub now_ms: i64,
    pub outcome: Outcome,
    #[serde(default)]
    pub output: Option<Value>,
    #[serde(default)]
    pub asking_rule_ids: Vec<String>,
    #[serde(default)]
    pub approver: Option<String>,
}
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum Verdict {
    Allow,
    Ask,
    Deny,
    Abstain,
}
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DecidingRule {
    pub rule_id: String,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub description: Option<String>,
    pub effect: String,
    pub ask: bool,
}
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ValidationResult {
    pub valid: bool,
    pub errors: Vec<String>,
    pub warnings: Vec<String>,
    pub stateful: bool,
    pub rule_ids: Vec<String>,
    pub policy_hash: String,
    pub core_version: String,
    pub language_version: String,
}
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct EventAlternatives {
    pub allow: Vec<PolicyEvent>,
    pub deny: Vec<PolicyEvent>,
}
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct EvaluationResult {
    pub verdict: Verdict,
    pub deciding_rules: Vec<DecidingRule>,
    pub errors: Vec<String>,
    pub valid_before: Option<i64>,
    pub policy_hash: String,
    pub events: EventAlternatives,
}
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct OutcomeResult {
    pub events: Vec<PolicyEvent>,
    pub errors: Vec<String>,
    pub policy_hash: String,
}

fn dogwood_kind() -> String {
    "dogwood".into()
}
