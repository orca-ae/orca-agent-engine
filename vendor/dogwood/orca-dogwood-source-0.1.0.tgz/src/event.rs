use crate::types::{EventKind, PolicyCall, PolicyEvent};
use dogwood_language::{Event, Value as DwValue};
use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::collections::BTreeMap;

pub(crate) fn json_value(value: &Value) -> Result<DwValue, String> {
    Ok(match value {
        Value::Null => DwValue::Null,
        Value::Bool(v) => DwValue::Bool(*v),
        Value::String(v) => DwValue::String(v.clone()),
        Value::Number(v) => {
            if let Some(value) = v.as_i64() {
                DwValue::Int(value)
            } else {
                DwValue::Decimal(v.to_string())
            }
        }
        Value::Array(v) => DwValue::Array(v.iter().map(json_value).collect::<Result<_, _>>()?),
        Value::Object(v) => DwValue::Object(
            v.iter()
                .map(|(key, value)| Ok((key.clone(), json_value(value)?)))
                .collect::<Result<_, String>>()?,
        ),
    })
}
fn ty(value: &str) -> Result<String, String> {
    let value = value.strip_prefix("Orca::").unwrap_or(value);
    if !matches!(
        value,
        "Vault"
            | "Unattributed"
            | "Caller"
            | "Developer"
            | "Agent"
            | "Gateway"
            | "Harness"
            | "Workspace"
    ) {
        return Err("unknown Orca entity type".into());
    }
    Ok(format!("Orca::{value}"))
}
pub(crate) fn check_call(call: &PolicyCall) -> Result<(), String> {
    if call.action.is_empty()
        || call.request_id.is_empty()
        || call.session_id.is_empty()
        || call.principal.id.is_empty()
        || call.resource.id.is_empty()
    {
        return Err("canonical action, request/session and entity identities are required".into());
    }
    if !matches!(
        call.principal
            .entity_type
            .strip_prefix("Orca::")
            .unwrap_or(&call.principal.entity_type),
        "Vault" | "Unattributed" | "Caller" | "Developer"
    ) || !matches!(
        call.resource
            .entity_type
            .strip_prefix("Orca::")
            .unwrap_or(&call.resource.entity_type),
        "Agent" | "Gateway" | "Harness"
    ) {
        return Err("invalid Orca principal/resource role".into());
    }
    for entity in [&call.principal, &call.resource] {
        ty(&entity.entity_type)?;
        if entity.parents.iter().any(|p| {
            !matches!(p.entity_type.as_str(), "Workspace" | "Orca::Workspace") || p.id.is_empty()
        }) {
            return Err("Orca parent identities must name a Workspace".into());
        }
    }
    Ok(())
}
pub(crate) fn check_time(time: i64) -> Result<(), String> {
    if !(0..=9_007_199_254_740_991).contains(&time) {
        Err("time must be a nonnegative exact JavaScript-safe epoch millisecond integer".into())
    } else {
        Ok(())
    }
}
pub(crate) type EventTypes = BTreeMap<(String, String), BTreeMap<Vec<String>, String>>;
pub(crate) fn event_types(policies: &dogwood_language::LoweredPolicySet) -> EventTypes {
    policies
        .event_signatures()
        .map(|signature| {
            let types = signature
                .fields()
                .filter_map(|field| match field.field_type() {
                    dogwood_language::EventFieldType::Cedar(kind) => {
                        Some((field.path().to_vec(), kind.clone()))
                    }
                    _ => None,
                })
                .collect();
            ((signature.action().into(), signature.kind().into()), types)
        })
        .collect()
}
fn typed_value(
    value: &Value,
    path: &[String],
    types: &BTreeMap<Vec<String>, String>,
    override_type: Option<&str>,
) -> Result<DwValue, String> {
    let expected = override_type
        .or_else(|| types.get(path).map(String::as_str))
        .unwrap_or("")
        .trim();
    if expected == "decimal" {
        let mut text = match value {
            Value::Number(number) => number.to_string(),
            Value::String(text) => text.clone(),
            _ => return Err("decimal field requires a number or decimal string".into()),
        };
        if !text.contains('.') && !text.contains(['e', 'E']) {
            text.push_str(".0");
        }
        return Ok(DwValue::Decimal(text));
    }
    if let Value::String(id) = value {
        if expected.starts_with("Orca::") {
            return Ok(DwValue::Entity {
                ty: expected.into(),
                id: id.clone(),
            });
        }
    }
    match value {
        Value::Object(map) => Ok(DwValue::Object(
            map.iter()
                .map(|(key, value)| {
                    let mut nested = path.to_vec();
                    nested.push(key.clone());
                    Ok((key.clone(), typed_value(value, &nested, types, None)?))
                })
                .collect::<Result<_, String>>()?,
        )),
        Value::Array(items) => {
            let member = expected
                .strip_prefix("Set")
                .map(str::trim)
                .and_then(|value| value.strip_prefix('<'))
                .and_then(|value| value.strip_suffix('>'))
                .map(str::trim);
            Ok(DwValue::Array(
                items
                    .iter()
                    .map(|value| typed_value(value, path, types, member))
                    .collect::<Result<_, _>>()?,
            ))
        }
        _ => json_value(value),
    }
}
pub(crate) fn to_event(event: &PolicyEvent) -> Result<Event, String> {
    to_event_with_types(event, &EventTypes::new())
}
pub(crate) fn to_event_with_types(
    event: &PolicyEvent,
    types: &EventTypes,
) -> Result<Event, String> {
    check_call(&event.call)?;
    check_time(event.timestamp_ms)?;
    match event.kind {
        EventKind::Approval
            if event.guardrail_id.as_ref().is_none_or(String::is_empty)
                || event.asked_by.as_ref().is_none_or(String::is_empty)
                || event.approver.as_ref().is_none_or(String::is_empty)
                || !matches!(event.result.as_deref(), Some("allow" | "deny")) =>
        {
            return Err(
                "approval requires guardrail, asked_by, approver and allow/deny result".into(),
            )
        }
        EventKind::Error
            if !matches!(
                event.error_type.as_deref(),
                Some("denied" | "failed" | "interrupted")
            ) =>
        {
            return Err("error event requires its explicit outcome type".into())
        }
        _ => {}
    }
    let call = &event.call;
    let principal = ty(&call.principal.entity_type)?;
    let resource = ty(&call.resource.entity_type)?;
    let empty = BTreeMap::new();
    let types = types
        .get(&(call.action.clone(), event.kind.as_str().into()))
        .unwrap_or(&empty);
    let input = typed_value(
        &serde_json::to_value(&call.input).map_err(|e| e.to_string())?,
        &["input".into()],
        types,
        None,
    )?;
    let mut builder = Event::builder_for(&["Orca", "Action"], &call.action, event.kind.as_str())
        .timestamp(event.timestamp_ms)
        .principal_for(&principal, &call.principal.id)
        .resource_for(&resource, &call.resource.id)
        .logged_field(
            "eventPrincipal",
            DwValue::Entity {
                ty: principal,
                id: call.principal.id.clone(),
            },
        )
        .logged_field(
            "eventResource",
            DwValue::Entity {
                ty: resource,
                id: call.resource.id.clone(),
            },
        )
        .logged_field("requestId", DwValue::String(call.request_id.clone()))
        .logged_field("sessionId", DwValue::String(call.session_id.clone()))
        .logged_field("input", input.clone())
        .request_context_field("input", input)
        .request_context_field("sessionId", DwValue::String(call.session_id.clone()));
    for entity in [&call.principal, &call.resource] {
        let entity_type = ty(&entity.entity_type)?;
        let attrs = entity
            .attributes
            .iter()
            .map(|(k, v)| Ok((k.as_str(), json_value(v)?)))
            .collect::<Result<Vec<_>, String>>()?;
        builder = builder.entity_for(&entity_type, &entity.id, attrs);
        let parents = entity
            .parents
            .iter()
            .map(|p| (String::from("Orca::Workspace"), p.id.clone()))
            .collect::<Vec<_>>();
        builder = builder.parents_for(
            &entity_type,
            &entity.id,
            parents.iter().map(|(t, id)| (t.as_str(), id.as_str())),
        );
    }
    if let Some(subject) = &call.subject {
        builder = builder.request_context_field("subject", json_value(subject)?);
    }
    if let Some(mcp) = &call.mcp {
        builder = builder.request_context_field("mcp", json_value(mcp)?);
    }
    for (name, value) in [
        ("output", event.output.as_ref()),
        (
            "errorType",
            event
                .error_type
                .as_ref()
                .map(|s| Value::String(s.clone()))
                .as_ref(),
        ),
        (
            "result",
            event
                .result
                .as_ref()
                .map(|s| Value::String(s.clone()))
                .as_ref(),
        ),
        (
            "askedBy",
            event
                .asked_by
                .as_ref()
                .map(|s| Value::String(s.clone()))
                .as_ref(),
        ),
        (
            "approver",
            event
                .approver
                .as_ref()
                .map(|s| Value::String(s.clone()))
                .as_ref(),
        ),
    ] {
        if let Some(value) = value {
            builder = builder.logged_field(name, typed_value(value, &[name.into()], types, None)?);
        }
    }
    Ok(builder.build())
}
pub(crate) fn make_event(call: &PolicyCall, kind: EventKind, now: i64) -> PolicyEvent {
    PolicyEvent {
        call: call.clone(),
        kind,
        timestamp_ms: now,
        guardrail_id: None,
        output: None,
        error_type: None,
        result: None,
        asked_by: None,
        approver: None,
    }
}
pub(crate) fn bounded(value: &Value) -> Value {
    let bytes = serde_json::to_vec(value).unwrap_or_default();
    if bytes.len() > 4096 {
        let text = String::from_utf8_lossy(&bytes);
        let prefix: String = text.chars().take(256).collect();
        json!({"sha256":hex::encode(Sha256::digest(&bytes)),"size":bytes.len(),"prefix":prefix})
    } else {
        value.clone()
    }
}
pub(crate) fn bounded_call(call: &PolicyCall) -> PolicyCall {
    let mut call = call.clone();
    call.input = call
        .input
        .into_iter()
        .map(|(k, v)| (k, bounded(&v)))
        .collect();
    call
}
