//! Exact milliseconds adapter over the real upstream temporal interpreter.
use dogwood_language::{
    cedar::Schema,
    engine::{InMemoryTemporalEngine, TemporalBindings, TemporalEngine, TemporalField},
    temporal_ast::{AggExprKind, Condition, ConditionKind, Term, WithinSpec},
    Event, EventSignature,
};

fn visit_term(
    term: &mut Term,
    windows: &mut Vec<i64>,
    operators: &mut usize,
    scale: bool,
) -> Result<(), String> {
    match term {
        Term::Agg(agg) => match &mut agg.kind {
            AggExprKind::Sum { body, .. } | AggExprKind::Count { body, .. } => {
                visit_condition(body, windows, operators, scale)?
            }
            AggExprKind::Call(_) => return Err("unexpanded aggregate macro".into()),
        },
        Term::Arith { left, right, .. } => {
            visit_term(left, windows, operators, scale)?;
            visit_term(right, windows, operators, scale)?;
        }
        Term::Array(items) => {
            for item in items {
                visit_term(item, windows, operators, scale)?;
            }
        }
        Term::ParamRef(_) | Term::BinderRef(_) => {
            return Err("unexpanded temporal parameter".into())
        }
        _ => {}
    }
    Ok(())
}
fn interval(
    within: &mut WithinSpec,
    windows: &mut Vec<i64>,
    operators: &mut usize,
    scale: bool,
) -> Result<(), String> {
    let WithinSpec::Concrete(value) = within else {
        return Err("unexpanded temporal window".into());
    };
    let seconds = value
        .checked_seconds()
        .filter(|n| *n > 0 && *n <= 86400)
        .ok_or("temporal window must be positive and at most 24 hours")?;
    windows.push(
        seconds
            .checked_mul(1000)
            .ok_or("temporal window overflow")?,
    );
    *operators += 1;
    if scale {
        value.amount = value
            .amount
            .checked_mul(1000)
            .ok_or("temporal millisecond conversion overflow")?;
    }
    Ok(())
}
pub(crate) fn visit_condition(
    c: &mut Condition,
    windows: &mut Vec<i64>,
    operators: &mut usize,
    scale: bool,
) -> Result<(), String> {
    match &mut c.kind {
        ConditionKind::And { left, right } | ConditionKind::Or { left, right } => {
            visit_condition(left, windows, operators, scale)?;
            visit_condition(right, windows, operators, scale)?;
        }
        ConditionKind::Not { inner } => visit_condition(inner, windows, operators, scale)?,
        ConditionKind::Formerly { within, body } | ConditionKind::Previous { within, body } => {
            interval(within, windows, operators, scale)?;
            visit_condition(body, windows, operators, scale)?;
        }
        ConditionKind::Since {
            left,
            within,
            right,
        } => {
            interval(within, windows, operators, scale)?;
            visit_condition(left, windows, operators, scale)?;
            visit_condition(right, windows, operators, scale)?;
        }
        ConditionKind::Exists { body, .. } => visit_condition(body, windows, operators, scale)?,
        ConditionKind::Comparison { left, right, .. } => {
            visit_term(left, windows, operators, scale)?;
            visit_term(right, windows, operators, scale)?;
        }
        ConditionKind::Predicate(p) => {
            for arg in &mut p.args {
                visit_term(&mut arg.value, windows, operators, scale)?;
            }
        }
        ConditionKind::Tp { .. } => {}
        ConditionKind::Call(_) | ConditionKind::SigilRef { .. } | ConditionKind::Refine { .. } => {
            return Err("unexpanded temporal condition".into())
        }
    }
    Ok(())
}
#[derive(Default)]
pub(crate) struct MillisEngine {
    inner: InMemoryTemporalEngine,
}
impl TemporalEngine for MillisEngine {
    fn prepare(
        &mut self,
        leaves: &[TemporalField],
        schema: &Schema,
        events: &[EventSignature],
    ) -> Result<(), dogwood_language::Error> {
        let mut scaled = leaves.to_vec();
        for leaf in &mut scaled {
            if let Err(message) =
                visit_condition(&mut leaf.condition.condition, &mut vec![], &mut 0, true)
            {
                return Err(dogwood_language::Error::EventSchema(message));
            }
        }
        self.inner.prepare(&scaled, schema, events)
    }
    fn observe(&mut self, event: &Event) {
        self.inner.observe(event)
    }
    fn evaluate(&mut self) -> Result<TemporalBindings, String> {
        self.inner.evaluate()
    }
}

pub(crate) fn valid_before(
    now: i64,
    times: impl Iterator<Item = i64>,
    windows: &[i64],
    stateful: bool,
) -> Result<Option<i64>, String> {
    if !stateful {
        return Ok(None);
    }
    // Upstream closed-window membership changes only at a retained event plus
    // one of the parsed windows, or at retention aging. Consider every event,
    // not merely the current matches: edits/nested conditions can read any of
    // them. Stop conservatively at each boundary. At equality a closed window
    // is still valid for this integer millisecond only, so use the next ms.
    let mut bound = now
        .checked_add(
            windows
                .iter()
                .copied()
                .min()
                .ok_or("temporal policy has no established finite window")?,
        )
        .ok_or("temporal deadline overflow")?;
    for time in times {
        for width in windows.iter().copied().chain(std::iter::once(86_400_000)) {
            let edge = time
                .checked_add(width)
                .ok_or("temporal deadline overflow")?;
            if edge > now {
                bound = bound.min(edge)
            } else if edge == now {
                bound = bound.min(now.checked_add(1).ok_or("temporal deadline overflow")?)
            }
        }
    }
    if bound <= now || bound > 9_007_199_254_740_991 {
        return Err("no exact conservative temporal authorization interval".into());
    }
    Ok(Some(bound))
}
