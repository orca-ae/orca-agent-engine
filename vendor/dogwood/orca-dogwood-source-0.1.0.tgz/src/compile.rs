use crate::{
    schema, temporal,
    types::{DecidingRule, Rule, ValidationResult},
};
use dogwood_language::{LoweredPolicySet, ParsedPolicySet, PolicySchema, ServiceSchema, Validator};
use serde_json::Value;
use sha2::{Digest, Sha256};
use std::collections::BTreeSet;

pub(crate) struct Prepared {
    pub lowered: LoweredPolicySet,
    pub service: ServiceSchema,
    pub schema: PolicySchema,
    pub rules: Vec<DecidingRule>,
    pub expanded: Vec<String>,
    pub windows: Vec<i64>,
    pub stateful: bool,
    pub warnings: Vec<String>,
    pub hash: String,
}
pub fn policy_hash(rule: &Rule) -> String {
    let mut normalized = rule.clone();
    normalized
        .mcp_manifests
        .sort_by(|a, b| a.server.cmp(&b.server));
    for manifest in &mut normalized.mcp_manifests {
        manifest.tools.sort_by(|a, b| {
            a.get("name")
                .and_then(Value::as_str)
                .cmp(&b.get("name").and_then(Value::as_str))
        });
    }
    hex::encode(Sha256::digest(
        serde_json::to_vec(&canonical_json(
            serde_json::to_value(&normalized).expect("Rule is JSON serializable"),
        ))
        .expect("canonical JSON is serializable"),
    ))
}
fn canonical_json(value: Value) -> Value {
    match value {
        Value::Object(map) => {
            let mut keys = map.keys().collect::<Vec<_>>();
            keys.sort();
            let mut result = serde_json::Map::new();
            for key in keys {
                result.insert(key.clone(), canonical_json(map[key].clone()));
            }
            Value::Object(result)
        }
        Value::Array(items) => Value::Array(items.into_iter().map(canonical_json).collect()),
        other => other,
    }
}
pub(crate) fn prepare(rule: &Rule) -> Result<Prepared, Vec<String>> {
    let hash = policy_hash(rule);
    let compile = || -> Result<Prepared, String> {
        if rule.kind != "dogwood" {
            return Err("rule kind must be dogwood".into());
        }
        if rule.policy.len() > 65536 {
            return Err("policy text exceeds 64 KiB".into());
        }
        let service = ServiceSchema::builder()
            .event_schema_str(schema::event_schema(rule.history))
            .build()
            .map_err(|e| e.to_string())?;
        let action_schema = schema::action_schema(rule)?;
        let action_schema =
            PolicySchema::from_cedarschema_str(&action_schema).map_err(|e| e.to_string())?;
        let parsed = ParsedPolicySet::parse(&rule.policy, &service).map_err(|e| e.to_string())?;
        let mut windows = Vec::new();
        let mut temporal_rules = 0;
        let mut expanded = Vec::new();
        for policy in parsed.policies() {
            if policy.uses_providers() {
                return Err("information providers are not allowed in Orca policies".into());
            }
            if policy.uses_temporal() {
                temporal_rules += 1;
            }
            let mut operators = 0;
            for condition in policy.temporal_conditions() {
                temporal::visit_condition(
                    &mut condition.clone(),
                    &mut windows,
                    &mut operators,
                    false,
                )?;
            }
            if operators > 3 {
                return Err("a rule exceeds three temporal operators".into());
            }
            expanded.push(policy.expanded_source());
        }
        if temporal_rules > 20 {
            return Err("a guardrail exceeds twenty temporal rules".into());
        }
        let lowered = parsed.lower(&action_schema).map_err(|e| e.to_string())?;
        let validation = Validator::new().validate(&lowered);
        let mut errors: Vec<_> = validation
            .validation_errors()
            .map(|e| e.to_string())
            .collect();
        errors.sort();
        errors.dedup();
        if !errors.is_empty() {
            return Err(errors.join("\n"));
        }
        let mut warnings: Vec<_> = validation
            .validation_warnings()
            .map(|e| e.to_string())
            .collect();
        let mut references: Vec<_> = lowered.rules().collect();
        references.sort_by_key(|r| r.rule_index);
        let mut rules = Vec::new();
        let mut ids = BTreeSet::new();
        let mut has_permit = false;
        for reference in references {
            let policy = lowered
                .as_cedar()
                .policies()
                .find(|p| p.id().to_string() == reference.cedar_policy_id)
                .ok_or("lowered rule metadata missing")?;
            let id = policy
                .annotation("id")
                .map(str::to_string)
                .unwrap_or_else(|| format!("rule-{}", reference.rule_index));
            if id.is_empty() || !ids.insert(id.clone()) {
                return Err("@id must be nonempty and unique within a policy set".into());
            }
            let description = policy.annotation("description").map(str::to_string);
            if description
                .as_ref()
                .is_some_and(|d| d.chars().count() > 1024)
            {
                return Err("@description exceeds 1024 characters".into());
            }
            let effect = if policy.effect() == cedar_policy::Effect::Permit {
                has_permit = true;
                "permit"
            } else {
                "forbid"
            };
            let ask = policy.annotation("ask").is_some();
            if ask && (effect != "forbid" || policy.annotation("ask") != Some("")) {
                return Err("@ask is allowed only as a valueless annotation on forbid".into());
            }
            if ask && policy.annotation("id").is_none() {
                return Err("an @ask rule requires an explicit @id for approval identity".into());
            }
            rules.push(DecidingRule {
                rule_id: id,
                description,
                effect: effect.into(),
                ask,
            });
        }
        if !has_permit {
            warnings.push("no permit in this policy set: every governed call is denied".into())
        }
        if rule.applies_to == crate::types::AppliesTo::McpTools
            && expanded.iter().any(|s| {
                s.contains("Orca::Action::\"bash\"") || s.contains("Orca::Action::\"BuiltinTool\"")
            })
        {
            warnings.push("appliesTo is mcp_tools, but a rule names a built-in tool".into())
        }
        warnings.sort();
        warnings.dedup();
        Ok(Prepared {
            lowered,
            service,
            schema: action_schema,
            rules,
            expanded,
            windows,
            stateful: temporal_rules > 0,
            warnings,
            hash: hash.clone(),
        })
    };
    compile().map_err(|e| vec![e])
}
pub fn validate_rule(rule: &Rule) -> ValidationResult {
    match prepare(rule) {
        Ok(p) => ValidationResult {
            valid: true,
            errors: vec![],
            warnings: p.warnings,
            stateful: p.stateful,
            rule_ids: p.rules.into_iter().map(|r| r.rule_id).collect(),
            policy_hash: p.hash,
            core_version: env!("CARGO_PKG_VERSION").into(),
            language_version: "1.1.0".into(),
        },
        Err(errors) => ValidationResult {
            valid: false,
            errors,
            warnings: vec![],
            stateful: false,
            rule_ids: vec![],
            policy_hash: policy_hash(rule),
            core_version: env!("CARGO_PKG_VERSION").into(),
            language_version: "1.1.0".into(),
        },
    }
}
