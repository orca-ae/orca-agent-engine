use crate::types::{AppliesTo, HistoryScope, McpManifest, Rule};
use cedar_policy::SchemaFragment;
use serde_json::{json, Value};
use std::collections::BTreeSet;

pub const BASE_SCHEMA: &str = include_str!("../schemas/orca.cedarschema");
pub const SESSION_EVENTS: &str = include_str!("../schemas/orca-session.dwschema");
pub const PRINCIPAL_EVENTS: &str = include_str!("../schemas/orca-principal.dwschema");
pub fn event_schema(scope: HistoryScope) -> &'static str {
    match scope {
        HistoryScope::Session => SESSION_EVENTS,
        HistoryScope::Principal => PRINCIPAL_EVENTS,
    }
}
fn safe_name(value: &str) -> bool {
    !value.is_empty()
        && value
            .bytes()
            .all(|c| c.is_ascii_alphanumeric() || matches!(c, b'_' | b'-'))
        && !value.contains("__")
}

/// Uses the upstream MCP schema generator, then adds only Orca-owned groups and
/// optional common context. Tool field types remain upstream-generated.
pub(crate) fn action_schema(rule: &Rule) -> Result<String, String> {
    if rule.mcp_manifests.is_empty() {
        return Ok(BASE_SCHEMA.into());
    }
    let mut template = BASE_SCHEMA.to_string();
    for name in ["Vault", "Unattributed", "Caller", "Developer"] {
        template = template.replace(
            &format!("    entity {name}"),
            &format!("    @mcp_principal\n    entity {name}"),
        );
    }
    for name in ["Agent", "Gateway", "Harness"] {
        template = template.replace(
            &format!("    entity {name}"),
            &format!("    @mcp_resource\n    entity {name}"),
        );
    }
    template=template.replace("    action \"McpTool\";", "    @mcp_action\n    action \"McpTool\";\n    @mcp_context(\"sessionId\")\n    type PolicySessionId = String;");
    let mut names = BTreeSet::new();
    let mut servers = BTreeSet::new();
    let mut urls = BTreeSet::new();
    let mut tools = Vec::new();
    for manifest in &rule.mcp_manifests {
        if !safe_name(&manifest.server) || !servers.insert(manifest.server.clone()) {
            return Err("MCP manifest server must be unique and use letters/digits/underscore/hyphen without __".into());
        }
        if !(manifest.url.starts_with("https://") || manifest.url.starts_with("http://"))
            || !urls.insert(manifest.url.clone())
        {
            return Err("MCP manifest URL must be a unique HTTP(S) origin/path".into());
        }
        for tool in &manifest.tools {
            let mut tool = tool.clone();
            let name = tool
                .get("name")
                .and_then(Value::as_str)
                .ok_or("MCP tool is missing name")?;
            if name.is_empty() {
                return Err("MCP tool name must not be empty".into());
            }
            let canonical = format!("mcp__{}__{name}", manifest.server);
            if !names.insert(canonical.clone()) {
                return Err("MCP tool names must be unique per server".into());
            }
            tool.as_object_mut()
                .ok_or("MCP tool must be an object")?
                .insert("name".into(), json!(canonical));
            tools.push(tool);
        }
    }
    let generated =
        dogwood_language::mcp_to_cedar_schema_with_template(&json!(tools).to_string(), &template)?;
    let (fragment, _) =
        SchemaFragment::from_cedarschema_str(&generated).map_err(|e| e.to_string())?;
    let mut schema = fragment.to_json_value().map_err(|e| e.to_string())?;
    let actions = schema["Orca"]["actions"]
        .as_object_mut()
        .ok_or("generated schema has no Orca actions")?;
    for server in servers {
        actions.insert(
            format!("mcp__{server}"),
            json!({"memberOf":[{"id":"McpTool"}]}),
        );
    }
    for action in names {
        let server = action
            .strip_prefix("mcp__")
            .and_then(|rest| rest.split_once("__"))
            .ok_or("invalid canonical MCP action")?
            .0;
        let value = actions
            .get_mut(&action)
            .ok_or("upstream MCP schema omitted canonical action")?;
        value["memberOf"] = json!([{"id":format!("mcp__{server}")}]);
        let attrs = value["appliesTo"]["context"]["attributes"]
            .as_object_mut()
            .ok_or("generated action has no context")?;
        attrs.insert(
            "subject".into(),
            json!({"type":"Orca::Subject","required":false}),
        );
        attrs.insert("mcp".into(), json!({"type":"Orca::Mcp","required":false}));
    }
    SchemaFragment::from_json_value(schema)
        .map_err(|e| e.to_string())?
        .to_cedarschema()
        .map_err(|e| e.to_string())
}

pub fn schemas() -> Value {
    json!({"base_schema":BASE_SCHEMA,"event_schemas":{"session":SESSION_EVENTS,"principal":PRINCIPAL_EVENTS},
      "language_version":"1.1.0","core_version":env!("CARGO_PKG_VERSION"),
      "limits":{"policy_bytes":65536,"temporal_rules":20,"temporal_operators_per_rule":3,"window_ms":86400000,"guardrails_per_session":16,"events_per_session":10000,"value_bytes":4096}})
}

pub fn canonical_tool(
    harness: &str,
    tool: &str,
    server_url: Option<&str>,
    manifests: &[McpManifest],
) -> Result<Value, String> {
    if !matches!(harness, "orca" | "claude_code" | "codex") {
        return Err("unknown tool harness".into());
    }
    if let Some(rest) = tool.strip_prefix("mcp__") {
        let (server, name) = rest
            .split_once("__")
            .filter(|(s, t)| !s.is_empty() && !t.is_empty())
            .ok_or("invalid MCP tool name")?;
        if harness == "orca"
            && server_url.is_none()
            && server == "orca"
            && matches!(
                name,
                "bash"
                    | "read"
                    | "write"
                    | "edit"
                    | "glob"
                    | "grep"
                    | "list"
                    | "delete"
                    | "web_fetch"
            )
        {
            return Ok(json!({"action":name,"is_mcp":false}));
        }
        let server = if let Some(url) = server_url {
            let matches: Vec<_> = manifests
                .iter()
                .filter(|manifest| manifest.url == url)
                .collect();
            if matches.len() != 1 {
                return Err("MCP URL has no unique manifest binding".into());
            }
            matches[0].server.as_str()
        } else {
            server
        };
        return Ok(json!({"action":format!("mcp__{server}__{name}"),"is_mcp":true}));
    }
    let action = match (harness, tool) {
        (
            _,
            "bash" | "read" | "write" | "edit" | "glob" | "grep" | "list" | "delete" | "web_fetch",
        ) => tool,
        ("orca" | "claude_code", "Bash") => "bash",
        ("orca" | "claude_code", "Read") => "read",
        ("orca" | "claude_code", "Write") => "write",
        ("orca" | "claude_code", "Edit" | "NotebookEdit") => "edit",
        ("orca" | "claude_code", "Glob") => "glob",
        ("orca" | "claude_code", "Grep") => "grep",
        ("orca" | "claude_code", "WebFetch") => "web_fetch",
        ("codex", "shell" | "shell_command" | "exec_command" | "functions.exec_command") => "bash",
        ("codex", "apply_patch" | "functions.apply_patch") => "edit",
        _ => return Err(format!("unknown {harness} tool mapping: {tool}")),
    };
    Ok(json!({"action":action,"is_mcp":false}))
}
pub(crate) fn applies(rule: &Rule, action: &str) -> bool {
    rule.applies_to == AppliesTo::AllTools || action.starts_with("mcp__")
}
