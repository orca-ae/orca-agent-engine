//! The pinned upstream temporal corpus runs against the real upstream engine.
use dogwood_language::{corpus, replay_log, LoweredPolicySet, PolicySchema, ServiceSchema};
use serde_json::{json, Value};
fn norm(text: &str) -> Vec<&str> {
    text.lines()
        .map(str::trim)
        .filter(|line| !line.is_empty())
        .collect()
}
pub fn run() -> Value {
    let mut passed = 0;
    let mut traces = 0;
    let mut rejected = 0;
    let mut failures = Vec::new();
    for case in corpus::temporal_cases() {
        let build = || -> Result<LoweredPolicySet, String> {
            let service = if let Some(events) = &case.event_schema_src {
                ServiceSchema::builder()
                    .event_schema_str(events)
                    .build()
                    .map_err(|e| e.to_string())?
            } else {
                ServiceSchema::builder()
                    .event_schema_str(include_str!(
                        "../vendor/dogwood-language/tests/fixtures/request_response.dwschema"
                    ))
                    .build()
                    .map_err(|e| e.to_string())?
            };
            let schema =
                PolicySchema::from_cedarschema_str(&case.schema_src).map_err(|e| e.to_string())?;
            LoweredPolicySet::from_str(&case.policy_src, &service, &schema)
                .map_err(|e| e.to_string())
        };
        if case.is_parse_rejected() {
            if match build() {
                Err(_) => true,
                Ok(policy) => !dogwood_language::Validator::new()
                    .validate(&policy)
                    .validation_passed(),
            } {
                rejected += 1
            } else {
                failures.push(format!(
                    "{}: expected parse/validation rejection",
                    case.name
                ))
            }
            continue;
        }
        if case.is_xfail() {
            failures.push(format!(
                "{}: upstream divergence is not a conforming case",
                case.name
            ));
            continue;
        }
        match build() {
            Ok(_policy) => {
                let before = failures.len();
                for trace in &case.traces {
                    traces += 1;
                    match build().and_then(|policy| {
                        replay_log(policy, &trace.trace_log).map_err(|e| e.to_string())
                    }) {
                        Ok(actual) if norm(&actual) == norm(&trace.expected) => {}
                        Ok(actual) => failures.push(format!(
                            "{} trace {}: verdict mismatch\n{}",
                            case.name, trace.index, actual
                        )),
                        Err(error) => {
                            failures.push(format!("{} trace {}: {}", case.name, trace.index, error))
                        }
                    }
                }
                if before == failures.len() {
                    passed += 1;
                }
            }
            Err(error) => failures.push(format!("{}: {}", case.name, error)),
        }
    }
    let mut macro_passed = 0;
    let mut macro_traces = 0;
    for case in corpus::macro_cases() {
        let build = || -> Result<LoweredPolicySet, String> {
            let mut service = ServiceSchema::builder().event_schema_str(include_str!(
                "../vendor/dogwood-language/tests/fixtures/request_response.dwschema"
            ));
            if let Some(events) = &case.event_schema_src {
                service = service.event_schema_str(events);
            }
            if let Some(macros) = &case.macros_src {
                service = service.macros_str(macros);
            }
            let service = service.build().map_err(|e| e.to_string())?;
            let schema =
                PolicySchema::from_cedarschema_str(&case.schema_src).map_err(|e| e.to_string())?;
            LoweredPolicySet::from_str(&case.policy_src, &service, &schema)
                .map_err(|e| e.to_string())
        };
        match build() {
            Ok(_policy) => {
                let before = failures.len();
                for trace in &case.traces {
                    macro_traces += 1;
                    match build().and_then(|policy| {
                        replay_log(policy, &trace.trace_log).map_err(|e| e.to_string())
                    }) {
                        Ok(actual) if norm(&actual) == norm(&trace.expected) => {}
                        Ok(actual) => failures.push(format!(
                            "macro {} trace {}: mismatch {}",
                            case.name, trace.index, actual
                        )),
                        Err(error) => failures.push(format!(
                            "macro {} trace {}: {}",
                            case.name, trace.index, error
                        )),
                    }
                }
                if before == failures.len() {
                    macro_passed += 1;
                }
            }
            Err(error) => failures.push(format!("macro {}: {}", case.name, error)),
        }
    }
    json!({"temporal_cases":passed,"temporal_traces":traces,"parse_rejected":rejected,"macro_cases":macro_passed,"macro_traces":macro_traces,"failures":failures})
}
