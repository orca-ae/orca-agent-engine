//! Pure shared Orca policy semantics over provenance-pinned Dogwood 1.1.0.
mod compile;
#[cfg(feature = "conformance")]
mod conformance;
mod event;
mod merge;
mod schema;
mod temporal;
pub mod types;

pub use compile::{policy_hash, validate_rule};
use dogwood_language::{Authorizer, LoweredPolicySet};
pub use merge::merge_events;
pub use schema::{canonical_tool, schemas};
use serde_json::{json, Value};
use std::collections::BTreeMap;
use types::*;

fn failed(request: &EvaluationRequest, errors: Vec<String>) -> EvaluationResult {
    EvaluationResult {
        verdict: Verdict::Deny,
        deciding_rules: vec![],
        errors,
        valid_before: None,
        policy_hash: policy_hash(&request.rule),
        events: EventAlternatives {
            allow: vec![],
            deny: vec![],
        },
    }
}
fn run(
    policies: LoweredPolicySet,
    history: &[PolicyEvent],
    candidate: &PolicyEvent,
) -> Result<dogwood_language::Response, String> {
    let types = event::event_types(&policies);
    let mut authorizer = Authorizer::builder(policies)
        .temporal_engine(temporal::MillisEngine::default())
        .build()
        .map_err(|e| e.to_string())?;
    for item in history {
        authorizer.is_authorized(&event::to_event_with_types(item, &types)?);
    }
    authorizer
        .is_authorized(&event::to_event_with_types(candidate, &types)?)
        .ok_or("candidate request did not decide".into())
}

pub fn evaluate(request: &EvaluationRequest) -> EvaluationResult {
    let prepared = match compile::prepare(&request.rule) {
        Ok(value) => value,
        Err(errors) => return failed(request, errors),
    };
    let evaluate = || -> Result<EvaluationResult, String> {
        event::check_time(request.now_ms)?;
        event::check_call(&request.call)?;
        if request.guardrail_id.is_empty() {
            return Err("guardrail_id is required".into());
        }
        if !prepared
            .lowered
            .event_signatures()
            .any(|sig| sig.action() == request.call.action && sig.kind() == "request")
        {
            return Err("call has no canonical action in the prepared Orca schema".into());
        }
        if !schema::applies(&request.rule, &request.call.action) {
            return Ok(EvaluationResult {
                verdict: Verdict::Abstain,
                deciding_rules: vec![],
                errors: vec![],
                valid_before: None,
                policy_hash: prepared.hash.clone(),
                events: EventAlternatives {
                    allow: vec![],
                    deny: vec![],
                },
            });
        }
        let mut previous = None;
        let mut counts = BTreeMap::<&str, usize>::new();
        let mut history = Vec::new();
        for item in &request.history {
            event::check_time(item.timestamp_ms)?;
            if item.timestamp_ms > request.now_ms
                || previous.is_some_and(|previous| item.timestamp_ms < previous)
            {
                return Err(
                    "history must be ordered and no later than authoritative now_ms".into(),
                );
            }
            previous = Some(item.timestamp_ms);
            // Validate even excluded approval envelopes; only the owning
            // guardrail's approvals are subsequently visible to evaluation.
            event::to_event(item)?;
            if item.timestamp_ms < request.now_ms.saturating_sub(86_400_000) {
                continue;
            }
            let count = counts.entry(&item.call.session_id).or_default();
            *count += 1;
            if *count > 10000 {
                return Err("session policy history exceeds 10000 events in 24 hours".into());
            }
            if item.kind == EventKind::Approval
                && item.guardrail_id.as_deref() != Some(request.guardrail_id.as_str())
            {
                continue;
            }
            history.push(item.clone());
        }
        let candidate = event::make_event(&request.call, EventKind::Request, request.now_ms);
        let response = run(prepared.lowered, &history, &candidate)?;
        let mut errors = response
            .diagnostics()
            .errors()
            .map(str::to_string)
            .collect::<Vec<_>>();
        let mut deciding = response
            .diagnostics()
            .reason()
            .map(|r| {
                prepared
                    .rules
                    .get(r.rule_index)
                    .cloned()
                    .ok_or("upstream returned an unknown deciding rule")
            })
            .collect::<Result<Vec<_>, _>>()?;
        deciding.sort_by(|a, b| a.rule_id.cmp(&b.rule_id));
        let mut verdict = if response.allowed() {
            Verdict::Allow
        } else {
            Verdict::Deny
        };
        if errors.is_empty() && verdict == Verdict::Deny && deciding.iter().any(|rule| rule.ask) {
            let without_asks = prepared
                .expanded
                .iter()
                .zip(&prepared.rules)
                .filter(|(_, rule)| !rule.ask)
                .map(|(source, _)| source.as_str())
                .collect::<Vec<_>>()
                .join("\n");
            let policies =
                LoweredPolicySet::from_str(&without_asks, &prepared.service, &prepared.schema)
                    .map_err(|e| e.to_string())?;
            let second = run(policies, &history, &candidate)?;
            errors.extend(second.diagnostics().errors().map(str::to_string));
            if second.allowed() && errors.is_empty() {
                verdict = Verdict::Ask;
            }
        }
        errors.sort();
        errors.dedup();
        if !errors.is_empty() {
            verdict = Verdict::Deny;
        }
        let valid_before = temporal::valid_before(
            request.now_ms,
            history.iter().map(|event| event.timestamp_ms),
            &prepared.windows,
            prepared.stateful,
        )?;
        let bounded = event::bounded_call(&request.call);
        let allowed = event::make_event(&bounded, EventKind::Request, request.now_ms);
        let mut denied = event::make_event(&bounded, EventKind::Error, request.now_ms);
        denied.error_type = Some("denied".into());
        Ok(EvaluationResult {
            verdict,
            deciding_rules: deciding,
            errors,
            valid_before,
            policy_hash: prepared.hash.clone(),
            events: EventAlternatives {
                allow: vec![allowed],
                deny: vec![denied],
            },
        })
    };
    match evaluate() {
        Ok(value) => value,
        Err(error) => failed(request, vec![error]),
    }
}

fn extract_output(raw: &Value) -> Option<Value> {
    if let Some(value) = raw.get("structuredContent") {
        return value.is_object().then(|| value.clone());
    }
    if let Some(contents) = raw.get("content").and_then(Value::as_array) {
        for content in contents {
            if content.get("type").and_then(Value::as_str) == Some("text") {
                if let Some(text) = content.get("text").and_then(Value::as_str) {
                    if let Ok(value) = serde_json::from_str::<Value>(text) {
                        if value.is_object() {
                            return Some(value);
                        }
                    }
                }
            }
        }
        return None;
    }
    raw.is_object().then(|| raw.clone())
}
fn value_at<'a>(value: &'a Value, path: &[String]) -> Option<&'a Value> {
    let mut value = value;
    for segment in path {
        value = value.get(segment)?;
    }
    Some(value)
}
fn set_path(target: &mut Value, path: &[String], value: Value) {
    if path.is_empty() {
        *target = value;
        return;
    }
    if !target.is_object() {
        *target = json!({});
    }
    let next = target
        .as_object_mut()
        .expect("constructed object")
        .entry(path[0].clone())
        .or_insert(Value::Null);
    set_path(next, &path[1..], value);
}
pub fn finalize_outcome(request: &OutcomeRequest) -> OutcomeResult {
    let hash = policy_hash(&request.rule);
    let prepared = match compile::prepare(&request.rule) {
        Ok(value) => value,
        Err(errors) => {
            return OutcomeResult {
                events: vec![],
                errors,
                policy_hash: hash,
            }
        }
    };
    let finalize = || -> Result<Vec<PolicyEvent>, String> {
        event::check_time(request.now_ms)?;
        event::check_call(&request.call)?;
        if !prepared
            .lowered
            .event_signatures()
            .any(|signature| signature.action() == request.call.action)
        {
            return Err("outcome action is absent from the prepared schema".into());
        }
        let call = event::bounded_call(&request.call);
        let kind = match request.outcome {
            Outcome::Allowed | Outcome::Approved => EventKind::Request,
            Outcome::Response => EventKind::Response,
            _ => EventKind::Error,
        };
        let mut recorded = event::make_event(&call, kind, request.now_ms);
        match request.outcome {
            Outcome::Denied | Outcome::Refused => recorded.error_type = Some("denied".into()),
            Outcome::Failed => recorded.error_type = Some("failed".into()),
            Outcome::Interrupted => recorded.error_type = Some("interrupted".into()),
            Outcome::Response if request.call.action.starts_with("mcp__") => {
                if let Some(raw) = request.output.as_ref().and_then(extract_output) {
                    let mut output = json!({});
                    for signature in prepared.lowered.event_signatures().filter(|signature| {
                        signature.action() == request.call.action && signature.kind() == "response"
                    }) {
                        for field in signature.fields().filter(|field| {
                            field.path().first().map(String::as_str) == Some("output")
                        }) {
                            let path = &field.path()[1..];
                            if let Some(value) = value_at(&raw, path) {
                                set_path(&mut output, path, event::bounded(value));
                            }
                        }
                    }
                    recorded.output = Some(output);
                }
            }
            _ => {}
        }
        let mut events = Vec::new();
        if matches!(request.outcome, Outcome::Approved | Outcome::Refused) {
            let approver = request
                .approver
                .as_ref()
                .filter(|value| !value.is_empty())
                .ok_or("approval outcome requires the authenticated approver")?;
            if request.guardrail_id.is_empty() || request.asking_rule_ids.is_empty() {
                return Err(
                    "approval outcome requires guardrail and asking rule identities".into(),
                );
            }
            let mut seen = std::collections::BTreeSet::new();
            for rule_id in &request.asking_rule_ids {
                if !seen.insert(rule_id)
                    || !prepared
                        .rules
                        .iter()
                        .any(|rule| rule.ask && rule.rule_id == *rule_id)
                {
                    return Err("approval names a duplicate or non-ask rule".into());
                }
                let mut approval = event::make_event(&call, EventKind::Approval, request.now_ms);
                approval.guardrail_id = Some(request.guardrail_id.clone());
                approval.asked_by = Some(rule_id.clone());
                approval.approver = Some(approver.clone());
                approval.result = Some(
                    if matches!(request.outcome, Outcome::Approved) {
                        "allow"
                    } else {
                        "deny"
                    }
                    .into(),
                );
                events.push(approval);
            }
        }
        events.push(recorded);
        Ok(events)
    };
    match finalize() {
        Ok(events) => OutcomeResult {
            events,
            errors: vec![],
            policy_hash: hash,
        },
        Err(error) => OutcomeResult {
            events: vec![],
            errors: vec![error],
            policy_hash: hash,
        },
    }
}

pub fn execute(input: Value) -> Result<Value, String> {
    let op = input
        .get("op")
        .and_then(Value::as_str)
        .ok_or("op is required")?;
    let serialize = |value| serde_json::to_value(value).map_err(|error| error.to_string());
    match op {
        "validate" => serialize(validate_rule(
            &serde_json::from_value::<Rule>(input.get("rule").cloned().ok_or("rule is required")?)
                .map_err(|e| e.to_string())?,
        )),
        "evaluate" => serde_json::to_value(evaluate(
            &serde_json::from_value(input).map_err(|e| e.to_string())?,
        ))
        .map_err(|e| e.to_string()),
        "finalize_outcome" => serde_json::to_value(finalize_outcome(
            &serde_json::from_value(input).map_err(|e| e.to_string())?,
        ))
        .map_err(|e| e.to_string()),
        "schemas" => Ok(schemas()),
        "merge_events" => serde_json::to_value(merge_events(
            &serde_json::from_value::<Vec<PolicyEvent>>(
                input.get("events").cloned().ok_or("events is required")?,
            )
            .map_err(|error| error.to_string())?,
        ))
        .map_err(|error| error.to_string()),
        "canonical_tool" => canonical_tool(
            input
                .get("harness")
                .and_then(Value::as_str)
                .ok_or("harness is required")?,
            input
                .get("tool")
                .and_then(Value::as_str)
                .ok_or("tool is required")?,
            input.get("server_url").and_then(Value::as_str),
            &serde_json::from_value::<Vec<McpManifest>>(
                input.get("manifests").cloned().unwrap_or(json!([])),
            )
            .map_err(|e| e.to_string())?,
        ),
        #[cfg(feature = "conformance")]
        "_conformance" => Ok(conformance::run()),
        _ => Err(format!("unknown operation: {op}")),
    }
}
pub fn execute_json(input: &str) -> String {
    let result = serde_json::from_str(input)
        .map_err(|e| e.to_string())
        .and_then(execute)
        .unwrap_or_else(|error| json!({"error":error,"verdict":"deny"}));
    serde_json::to_string(&result).expect("core response is JSON serializable")
}
#[cfg(target_arch = "wasm32")]
#[wasm_bindgen::prelude::wasm_bindgen(js_name=execute_json)]
pub fn wasm_execute_json(input: &str) -> String {
    execute_json(input)
}
