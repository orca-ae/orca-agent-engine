//! Merge the projections of one canonical call outcome, without multiplying
//! its request reservation. This owns no authorization or storage decisions.
use crate::{event, types::*};
use serde_json::Value;
use std::collections::BTreeMap;

fn union(target: &mut Value, incoming: &Value, path: &str) -> Result<(), String> {
    if target == incoming {
        return Ok(());
    }
    if let (Value::Object(target), Value::Object(incoming)) = (&mut *target, incoming) {
        for (key, value) in incoming {
            if let Some(previous) = target.get_mut(key) {
                union(previous, value, &format!("{path}.{key}"))?;
            } else {
                target.insert(key.clone(), value.clone());
            }
        }
        Ok(())
    } else {
        Err(format!("conflicting event projection at {path}"))
    }
}

pub fn merge_events(events: &[PolicyEvent]) -> MergedEvents {
    let merge = || -> Result<Vec<PolicyEvent>, String> {
        let mut common = events.first().map(|event| event.call.clone());
        if let Some(common) = &mut common {
            common.input.clear();
        }
        let mut groups = BTreeMap::<String, usize>::new();
        let mut merged: Vec<PolicyEvent> = Vec::new();
        for item in events {
            event::check_time(item.timestamp_ms)?;
            event::to_event(item)?;
            if item.output.as_ref().is_some_and(|value| !value.is_object()) {
                return Err("event output projection must be a record".into());
            }
            let mut identity = item.call.clone();
            identity.input.clear();
            if common.as_ref() != Some(&identity)
                || events.first().map(|first| first.timestamp_ms) != Some(item.timestamp_ms)
            {
                return Err(
                    "event projections have different canonical call or authority time".into(),
                );
            }
            let key = serde_json::to_string(&(
                item.kind,
                &item.error_type,
                &item.guardrail_id,
                &item.asked_by,
            ))
            .map_err(|error| error.to_string())?;
            if let Some(index) = groups.get(&key) {
                let target = &mut merged[*index];
                let mut metadata = target.clone();
                metadata.call.input.clear();
                metadata.output = None;
                let mut incoming_metadata = item.clone();
                incoming_metadata.call.input.clear();
                incoming_metadata.output = None;
                if metadata != incoming_metadata {
                    return Err("event projection metadata conflicts".into());
                }
                for (key, value) in &item.call.input {
                    if let Some(previous) = target.call.input.get_mut(key) {
                        union(previous, value, &format!("input.{key}"))?;
                    } else {
                        target.call.input.insert(key.clone(), value.clone());
                    }
                }
                if let Some(output) = &item.output {
                    if let Some(previous) = &mut target.output {
                        union(previous, output, "output")?;
                    } else {
                        target.output = Some(output.clone());
                    }
                }
            } else {
                groups.insert(key, merged.len());
                merged.push(item.clone());
            }
        }
        for item in &mut merged {
            item.call = event::bounded_call(&item.call);
            if let Some(Value::Object(output)) = &mut item.output {
                for value in output.values_mut() {
                    *value = event::bounded(value);
                }
            }
        }
        // Every approval must be visible before the single request that can
        // consume it, including approvals emitted by later policy projections.
        merged.sort_by_key(|event| event.kind != EventKind::Approval);
        Ok(merged)
    };
    match merge() {
        Ok(events) => MergedEvents {
            events,
            errors: vec![],
        },
        Err(error) => MergedEvents {
            events: vec![],
            errors: vec![error],
        },
    }
}
