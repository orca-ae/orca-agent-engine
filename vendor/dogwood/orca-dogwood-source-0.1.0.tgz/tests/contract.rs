use orca_dogwood::{evaluate, finalize_outcome, types::*, validate_rule};
use serde_json::json;
fn rule(policy: &str) -> Rule {
    serde_json::from_value(json!({"policy":policy})).unwrap()
}
fn call(session: &str) -> PolicyCall {
    serde_json::from_value(json!({"action":"bash","principal":{"type":"Developer","id":"usr-1"},"resource":{"type":"Harness","id":"codex"},"request_id":"tool-1","session_id":session,"input":{"command":"git push origin main"}})).unwrap()
}
fn evaluation_request(rule: Rule) -> EvaluationRequest {
    EvaluationRequest {
        guardrail_id: "grd-1".into(),
        rule,
        now_ms: 2000,
        history: vec![],
        call: call("s-1"),
    }
}
const ALLOW: &str = r#"@id("baseline") permit(principal,action,resource);"#;
const ASK: &str = r#"
@id("baseline") permit(principal,action,resource);
@id("push") @ask @description("A push needs approval")
forbid(principal,action == Orca::Action::"bash",resource)
when { context.input.command like "git push*" }
unless temporal { formerly within 1h Orca::Action::"bash"::approval{askedBy:"push",result:"allow"} };
"#;
#[test]
fn actual_upstream_stateless_allow_deny_and_default_deny() {
    let result = evaluate(&evaluation_request(rule(ALLOW)));
    assert!(result.errors.is_empty(), "{:?}", result.errors);
    assert_eq!(result.verdict, Verdict::Allow);
    assert_eq!(result.valid_before, None);
    let only_forbid = r#"@id("no-force") forbid(principal,action == Orca::Action::"bash",resource) when {context.input.command like "git push --force*"};"#;
    let validation = validate_rule(&rule(only_forbid));
    assert!(validation.valid, "{:?}", validation.errors);
    assert!(!validation.warnings.is_empty());
    assert_eq!(
        evaluate(&evaluation_request(rule(only_forbid))).verdict,
        Verdict::Deny
    );
}
#[test]
fn ask_uses_second_evaluation_and_scopes_approvals_to_guardrail() {
    let mut request = evaluation_request(rule(ASK));
    let initial = evaluate(&request);
    assert!(initial.errors.is_empty(), "{:?}", initial.errors);
    assert_eq!(initial.verdict, Verdict::Ask);
    assert!(initial.valid_before.is_some());
    let approval = finalize_outcome(&OutcomeRequest {
        guardrail_id: "grd-1".into(),
        rule: request.rule.clone(),
        call: request.call.clone(),
        now_ms: 1000,
        outcome: Outcome::Approved,
        output: None,
        asking_rule_ids: vec!["push".into()],
        approver: Some("usr-admin".into()),
    });
    assert!(approval.errors.is_empty(), "{:?}", approval.errors);
    request.history = approval.events;
    let allowed = evaluate(&request);
    assert!(allowed.errors.is_empty(), "{:?}", allowed.errors);
    assert_eq!(allowed.verdict, Verdict::Allow);
    assert_eq!(allowed.valid_before, Some(3601000));
    request.guardrail_id = "grd-other".into();
    assert_eq!(evaluate(&request).verdict, Verdict::Ask);
    let no_baseline = ASK.replace(ALLOW, "");
    assert_eq!(
        evaluate(&evaluation_request(rule(&no_baseline))).verdict,
        Verdict::Deny
    );
}
#[test]
fn exclusive_validity_bound_matches_real_subsecond_upstream_window() {
    let mut request = evaluation_request(rule(ASK));
    request.history = finalize_outcome(&OutcomeRequest {
        guardrail_id: "grd-1".into(),
        rule: request.rule.clone(),
        call: request.call.clone(),
        now_ms: 1001,
        outcome: Outcome::Approved,
        output: None,
        asking_rule_ids: vec!["push".into()],
        approver: Some("admin".into()),
    })
    .events;
    request.now_ms = 3601000;
    let allowed = evaluate(&request);
    assert_eq!(allowed.verdict, Verdict::Allow);
    assert_eq!(allowed.valid_before, Some(3601001));
    request.now_ms = 3601002;
    let expired = evaluate(&request);
    assert_eq!(expired.verdict, Verdict::Ask);
    assert!(expired.valid_before.is_some());
}

#[test]
fn temporal_deadlines_that_cannot_be_json_exact_fail_closed() {
    let mut request = evaluation_request(rule(ASK));
    request.now_ms = 9_007_199_254_740_990;
    let result = evaluate(&request);
    assert_eq!(result.verdict, Verdict::Deny);
    assert!(!result.errors.is_empty());
    assert_eq!(result.valid_before, None);
}
#[test]
fn unknown_and_malformed_inputs_fail_closed() {
    let mut request = evaluation_request(rule(ALLOW));
    request.call.action = "BashTypo".into();
    let result = evaluate(&request);
    assert_eq!(result.verdict, Verdict::Deny);
    assert!(!result.errors.is_empty());
    assert!(!validate_rule(&rule("not a policy")).valid);
    assert!(!validate_rule(&rule("@ask permit(principal,action,resource);")).valid);
    let rule=rule("@id(\"a\") permit(principal,action,resource); @id(\"a\") forbid(principal,action,resource);");
    assert!(!validate_rule(&rule).valid);
}
#[test]
fn temporal_count_reserves_only_authorized_requests_and_survives_interruption() {
    let policy = r#"@id("baseline") permit(principal,action,resource); @id("one") forbid(principal,action == Orca::Action::"bash",resource) when temporal { count_within(1h,Orca::Action::"bash"::request{}) > 1 };"#;
    let mut request = evaluation_request(rule(policy));
    let first = evaluate(&request);
    assert!(first.errors.is_empty(), "{:?}", first.errors);
    assert_eq!(first.verdict, Verdict::Allow);
    request.history = first.events.deny;
    request.now_ms += 1;
    assert_eq!(evaluate(&request).verdict, Verdict::Allow);
    let allowed = evaluate(&request);
    request.history = allowed.events.allow;
    request.now_ms += 1;
    assert_eq!(evaluate(&request).verdict, Verdict::Deny);
    request.history.extend(
        finalize_outcome(&OutcomeRequest {
            guardrail_id: "grd-1".into(),
            rule: request.rule.clone(),
            call: request.call.clone(),
            now_ms: request.now_ms,
            outcome: Outcome::Interrupted,
            output: None,
            asking_rule_ids: vec![],
            approver: None,
        })
        .events,
    );
    request.now_ms += 1;
    assert_eq!(evaluate(&request).verdict, Verdict::Deny);
}
#[test]
fn session_and_principal_history_pins_differ_without_resetting_events() {
    let policy = r#"@id("baseline") permit(principal,action,resource); @id("one") forbid(principal,action == Orca::Action::"bash",resource) when temporal { count_within(1h,Orca::Action::"bash"::request{}) > 1 };"#;
    let first = evaluation_request(rule(policy));
    let history = evaluate(&first).events.allow;
    let mut second = evaluation_request(rule(policy));
    second.now_ms += 1;
    second.call.session_id = "s-2".into();
    second.history = history;
    assert_eq!(evaluate(&second).verdict, Verdict::Allow);
    second.rule.history = HistoryScope::Principal;
    assert_eq!(evaluate(&second).verdict, Verdict::Deny);
}
#[test]
fn canonical_mapping_and_applicability_are_explicit() {
    assert_eq!(
        orca_dogwood::canonical_tool("codex", "exec_command", None, &[]).unwrap()["action"],
        "bash"
    );
    assert!(orca_dogwood::canonical_tool("other", "Bash", None, &[]).is_err());
    let mut request = evaluation_request(rule(ALLOW));
    request.rule.applies_to = AppliesTo::McpTools;
    assert_eq!(evaluate(&request).verdict, Verdict::Abstain);
}

#[test]
fn external_mcp_alias_cannot_claim_the_orca_builtin_namespace() {
    let manifests = vec![serde_json::from_value(json!({
        "server":"external", "url":"https://mcp.example/tools", "tools":[]
    }))
    .unwrap()];
    let alias = orca_dogwood::canonical_tool(
        "claude_code",
        "mcp__orca__bash",
        Some("https://mcp.example/tools"),
        &manifests,
    )
    .unwrap();
    assert_eq!(alias["action"], "mcp__external__bash");
    assert_eq!(alias["is_mcp"], true);
    let builtin = orca_dogwood::canonical_tool("orca", "mcp__orca__bash", None, &[]).unwrap();
    assert_eq!(builtin["action"], "bash");
    assert_eq!(builtin["is_mcp"], false);
}

fn mcp_rule(policy: &str) -> Rule {
    serde_json::from_value(json!({"kind":"dogwood","policy":policy,"appliesTo":"mcp_tools","mcpManifests":[{"server":"jira","url":"https://mcp.example.com/jira","tools":[{"name":"create_issue","inputSchema":{"type":"object","properties":{"project":{"type":"string"},"amount":{"type":"integer"},"ratio":{"type":"number"}},"required":["project","amount","ratio"],"additionalProperties":false},"outputSchema":{"type":"object","properties":{"key":{"type":"string"}},"required":["key"],"additionalProperties":false}}]}]})).unwrap()
}
fn mcp_request(policy: &str) -> EvaluationRequest {
    let mut input = evaluation_request(mcp_rule(policy));
    input.call.action = "mcp__jira__create_issue".into();
    input.call.input =
        serde_json::from_value(json!({"project":"SEC","amount":12,"ratio":1.5})).unwrap();
    input.call.mcp = Some(json!({"server":"jira","server_host":"mcp.example.com"}));
    input
}

fn direct_mcp_request(policy: &str) -> EvaluationRequest {
    let mut request = mcp_request(policy);
    request.call.principal = serde_json::from_value(json!({
        "type":"Caller", "id":"caller-1", "attributes":{"subject":"api_key:key-1"},
        "parents":[{"type":"Workspace","id":"wk-1"}]
    }))
    .unwrap();
    request.call.resource = serde_json::from_value(json!({
        "type":"Gateway", "id":"gateway-1",
        "parents":[{"type":"Workspace","id":"wk-1"}]
    }))
    .unwrap();
    request.call.subject = Some(json!({"kind":"api_key","id":"key-1"}));
    request
}

#[test]
fn direct_caller_and_gateway_workspace_parents_conform_to_real_cedar_schema() {
    let request = direct_mcp_request(ALLOW);
    let result = evaluate(&request);
    assert!(result.errors.is_empty(), "{:?}", result.errors);
    assert_eq!(result.verdict, Verdict::Allow);
}

#[test]
fn direct_policy_checks_workspace_membership_and_authenticated_subject_fields() {
    let policy = r#"@id("bound")
permit(principal == Orca::Caller::"caller-1", action == Orca::Action::"mcp__jira__create_issue", resource == Orca::Gateway::"gateway-1")
when {
    principal in Orca::Workspace::"wk-1" && resource in Orca::Workspace::"wk-1" &&
    principal.subject == "api_key:key-1" && context has subject &&
    context.subject.kind == "api_key" && context.subject.id == "key-1"
};"#;
    let request = direct_mcp_request(policy);
    let validation = validate_rule(&request.rule);
    assert!(validation.valid, "{:?}", validation.errors);
    let allowed = evaluate(&request);
    assert!(allowed.errors.is_empty(), "{:?}", allowed.errors);
    assert_eq!(allowed.verdict, Verdict::Allow);
    for principal_parent in [true, false] {
        let mut other = request.clone();
        let entity = if principal_parent {
            &mut other.call.principal
        } else {
            &mut other.call.resource
        };
        entity.parents[0].id = "wk-other".into();
        assert_eq!(evaluate(&other).verdict, Verdict::Deny);
    }
    let mut wrong_subject = request.clone();
    wrong_subject
        .call
        .principal
        .attributes
        .insert("subject".into(), json!("api_key:other"));
    assert_eq!(evaluate(&wrong_subject).verdict, Verdict::Deny);
    wrong_subject.call.principal.attributes.remove("subject");
    let missing = evaluate(&wrong_subject);
    assert_eq!(missing.verdict, Verdict::Deny);
    assert!(!missing.errors.is_empty());
    let mut wrong_context = request;
    wrong_context.call.subject = Some(json!({"kind":"api_key","id":"other"}));
    assert_eq!(evaluate(&wrong_context).verdict, Verdict::Deny);
}
#[test]
fn actual_upstream_mcp_schema_generation_and_output_projection() {
    let input = mcp_request(ALLOW);
    let validation = validate_rule(&input.rule);
    assert!(validation.valid, "{:?}", validation.errors);
    let decision = evaluate(&input);
    assert!(decision.errors.is_empty(), "{:?}", decision.errors);
    assert_eq!(decision.verdict, Verdict::Allow);
    let result = finalize_outcome(&OutcomeRequest {
        guardrail_id: input.guardrail_id,
        rule: input.rule,
        call: input.call,
        now_ms: 2001,
        outcome: Outcome::Response,
        output: Some(json!({"structuredContent":{"key":"SEC-12","secret":"should not be logged"}})),
        asking_rule_ids: vec![],
        approver: None,
    });
    assert!(result.errors.is_empty(), "{:?}", result.errors);
    assert_eq!(result.events[0].output, Some(json!({"key":"SEC-12"})));
}
#[test]
fn annotation_and_temporal_resource_limits_are_validated_before_use() {
    let long = rule(&format!(
        "@description(\"{}\") permit(principal,action,resource);",
        "x".repeat(1025)
    ));
    assert!(!validate_rule(&long).valid);
    let week = rule(
        r#"@id("baseline") permit(principal,action,resource); forbid(principal,action == Orca::Action::"bash",resource) when temporal {formerly within 7d Orca::Action::"bash"::request{}};"#,
    );
    assert!(!validate_rule(&week).valid);
    let too_many=rule(&(0..21).map(|index|format!("@id(\"r{index}\") forbid(principal,action == Orca::Action::\"bash\",resource) when temporal {{formerly within 1h Orca::Action::\"bash\"::request{{}}}};\n")).collect::<String>());
    assert!(!validate_rule(&too_many).valid);
    let operators = rule(
        r#"forbid(principal,action == Orca::Action::"bash",resource) when temporal {formerly within 1h (formerly within 1h (formerly within 1h (formerly within 1h Orca::Action::"bash"::request{})))};"#,
    );
    assert!(!validate_rule(&operators).valid);
}
#[test]
fn changed_policy_uses_existing_history_and_has_a_different_content_hash() {
    let mut input = evaluation_request(rule(ALLOW));
    let first = evaluate(&input);
    input.history = first.events.allow;
    input.now_ms += 1;
    input.rule.policy=r#"@id("baseline") permit(principal,action,resource); @id("new-cap") forbid(principal,action == Orca::Action::"bash",resource) when temporal {count_within(24h,Orca::Action::"bash"::request{}) > 1};"#.into();
    let edited = evaluate(&input);
    assert!(edited.errors.is_empty(), "{:?}", edited.errors);
    assert_eq!(edited.verdict, Verdict::Deny);
    assert_ne!(edited.policy_hash, first.policy_hash);
    assert!(edited.valid_before.is_some());
}

#[test]
fn mcp_number_fields_use_the_generated_decimal_type_even_for_integer_json() {
    let policy = r#"@id("one") permit(principal,action == Orca::Action::"mcp__jira__create_issue",resource) when {context.input.ratio == decimal("1.0")};"#;
    let mut input = mcp_request(policy);
    input.call.input.insert("ratio".into(), json!(1));
    let result = evaluate(&input);
    assert!(result.errors.is_empty(), "{:?}", result.errors);
    assert_eq!(result.verdict, Verdict::Allow);
}
