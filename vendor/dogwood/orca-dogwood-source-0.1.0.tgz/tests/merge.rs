use orca_dogwood::execute;
use serde_json::{json, Value};

fn event(kind: &str, input: Value, output: Option<Value>) -> Value {
    let mut event = json!({
        "kind":kind,"timestamp_ms":2000,"action":"mcp__jira__create_issue",
        "principal":{"type":"Caller","id":"caller-1","attributes":{"subject":"api_key:key-1"},"parents":[{"type":"Workspace","id":"wk-1"}]},
        "resource":{"type":"Gateway","id":"gateway-1","parents":[{"type":"Workspace","id":"wk-1"}]},
        "request_id":"tool-1","session_id":"s-1","subject":{"kind":"api_key","id":"key-1"},
        "input":input
    });
    if let Some(output) = output {
        event["output"] = output;
    }
    event
}
fn merge(events: Vec<Value>) -> Value {
    execute(json!({"op":"merge_events","events":events})).unwrap()
}

#[test]
fn actual_two_policy_outcome_projections_merge_without_losing_fields() {
    let call = event("request", json!({"project":"SEC"}), None);
    let rule = |field: &str| json!({"policy":"@id(\"base\") permit(principal,action,resource);","mcpManifests":[{"server":"jira","url":"https://mcp.example/jira","tools":[{"name":"create_issue","inputSchema":{"type":"object","properties":{"project":{"type":"string"}},"required":["project"]},"outputSchema":{"type":"object","properties":{"payload":{"type":"object","properties":{field:{"type":"string"}},"required":[field]}},"required":["payload"]}}]}]});
    let mut requests = vec![];
    let mut responses = vec![];
    for field in ["key", "state"] {
        let mut candidate = call.clone();
        candidate.as_object_mut().unwrap().remove("kind");
        candidate.as_object_mut().unwrap().remove("timestamp_ms");
        let decision=execute(json!({"op":"evaluate","guardrail_id":field,"rule":rule(field),"now_ms":2000,"history":[],"call":candidate})).unwrap();
        assert_eq!(decision["verdict"], "allow", "{decision}");
        requests.extend(
            decision["events"]["allow"]
                .as_array()
                .unwrap()
                .iter()
                .cloned(),
        );
        let outcome=execute(json!({"op":"finalize_outcome","guardrail_id":field,"rule":rule(field),"now_ms":2001,"call":candidate,"outcome":"response","output":{"structuredContent":{"payload":{"key":"SEC-1","state":"open"}}}})).unwrap();
        assert_eq!(outcome["errors"], json!([]));
        responses.extend(outcome["events"].as_array().unwrap().iter().cloned());
    }
    let request = merge(requests);
    assert_eq!(request["errors"], json!([]));
    assert_eq!(request["events"].as_array().unwrap().len(), 1);
    let response = merge(responses);
    assert_eq!(response["errors"], json!([]));
    assert_eq!(response["events"].as_array().unwrap().len(), 1);
    assert_eq!(
        response["events"][0]["output"],
        json!({"payload":{"key":"SEC-1","state":"open"}})
    );
}

#[test]
fn real_shared_merge_unions_two_policy_projections_without_double_reservation() {
    let request = event("request", json!({"project":"SEC"}), None);
    let result = merge(vec![
        request.clone(),
        request,
        event(
            "response",
            json!({"payload":{"a":1}}),
            Some(json!({"payload":{"key":"SEC-1"}})),
        ),
        event(
            "response",
            json!({"payload":{"b":2}}),
            Some(json!({"payload":{"state":"open"}})),
        ),
    ]);
    assert_eq!(result["errors"], json!([]));
    let events = result["events"].as_array().unwrap();
    assert_eq!(events.len(), 2);
    assert_eq!(
        events
            .iter()
            .filter(|event| event["kind"] == "request")
            .count(),
        1
    );
    assert_eq!(events[1]["input"], json!({"payload":{"a":1,"b":2}}));
    assert_eq!(
        events[1]["output"],
        json!({"payload":{"key":"SEC-1","state":"open"}})
    );
}

#[test]
fn scalar_type_or_authority_identity_conflicts_return_no_events() {
    let first = event("request", json!({"command":"first"}), None);
    for changed in [
        event("request", json!({"command":"second"}), None),
        event("request", json!({"command":{"nested":true}}), None),
        {
            let mut event = first.clone();
            event["timestamp_ms"] = json!(2001);
            event
        },
        {
            let mut event = first.clone();
            event["principal"]["id"] = json!("another");
            event
        },
    ] {
        let result = merge(vec![first.clone(), changed]);
        assert_eq!(result["events"], json!([]));
        assert!(!result["errors"].as_array().unwrap().is_empty());
    }
}

#[test]
fn merged_input_and_output_values_are_bounded_after_projection_union() {
    let result = merge(vec![
        event(
            "response",
            json!({"payload":{"a":"x".repeat(2500)}}),
            Some(json!({"payload":{"a":"x".repeat(2500)}})),
        ),
        event(
            "response",
            json!({"payload":{"b":"y".repeat(2500)}}),
            Some(json!({"payload":{"b":"y".repeat(2500)}})),
        ),
    ]);
    assert_eq!(result["errors"], json!([]));
    for field in ["input", "output"] {
        let bounded = &result["events"][0][field]["payload"];
        assert_eq!(bounded["sha256"].as_str().unwrap().len(), 64);
        assert!(bounded["size"].as_u64().unwrap() > 4096);
        assert!(bounded["prefix"].as_str().unwrap().chars().count() <= 256);
        assert!(bounded.get("a").is_none());
    }
}

#[test]
fn approvals_keep_guardrail_and_asking_rule_identity() {
    let approval = |guardrail: &str, asked_by: &str| {
        let mut event = event("approval", json!({"project":"SEC"}), None);
        event["guardrail_id"] = json!(guardrail);
        event["asked_by"] = json!(asked_by);
        event["result"] = json!("allow");
        event["approver"] = json!("admin");
        event
    };
    let result = merge(vec![
        approval("grd-1", "ask-1"),
        approval("grd-2", "ask-1"),
        approval("grd-1", "ask-2"),
        approval("grd-1", "ask-1"),
    ]);
    assert_eq!(result["errors"], json!([]));
    assert_eq!(result["events"].as_array().unwrap().len(), 3);
}

#[test]
fn every_approval_precedes_the_one_consuming_request() {
    let approval = |guardrail: &str| {
        let mut event = event("approval", json!({"project":"SEC"}), None);
        event["guardrail_id"] = json!(guardrail);
        event["asked_by"] = json!("one-use");
        event["result"] = json!("allow");
        event["approver"] = json!("admin");
        event
    };
    let request = event("request", json!({"project":"SEC"}), None);
    let result = merge(vec![
        approval("grd-1"),
        request.clone(),
        approval("grd-2"),
        request,
    ]);
    assert_eq!(result["errors"], json!([]));
    let kinds = result["events"]
        .as_array()
        .unwrap()
        .iter()
        .map(|event| event["kind"].clone())
        .collect::<Vec<_>>();
    assert_eq!(
        kinds,
        vec![json!("approval"), json!("approval"), json!("request")]
    );
}
