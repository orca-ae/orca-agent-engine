# Native clock helper

This tiny binary is a separate workspace package. It supplies only native clock
samples to Node's dispatch/lease reader and never enters pure core evaluation.
Linux uses CLOCK_BOOTTIME and /proc/sys/kernel/random/boot_id. Darwin uses the
platform-documented suspend-inclusive CLOCK_MONOTONIC plus kern.bootsessionuuid.
Unknown platforms, unsafe integer conversions and boot identity changes fail.

Build the local helper with `cargo +1.94.0 build -p orca-dogwood-clock --release`.
Linux release CI builds the same package natively for each image architecture,
or with its qualified cross linker and Rust target, and places the executable
under `package/bin/linux-<node-arch>/orca-dogwood-clock`. Darwin packaging uses
`darwin-<node-arch>`. The stage script records SHA-256 in package provenance.
No helper is guessed or downloaded by a consumer at runtime. A deployment must
still qualify its Registry excess-clock-advance plus local elapsed undercount
bound; this implementation supplies no implicit zero-error assumption.
