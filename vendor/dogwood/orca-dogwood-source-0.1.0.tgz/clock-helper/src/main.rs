//! Native lease/dispatch clock transport. Deliberately separate from the pure
//! Dogwood evaluator; it owns no policy semantics or clocks within that API.
fn main() {
    match reading() {
        Ok(value) => println!("{value}"),
        Err(message) => {
            eprintln!("orca-dogwood-clock: {message}");
            std::process::exit(1)
        }
    }
}
#[cfg(any(target_os = "linux", target_os = "macos"))]
fn boot_id() -> Result<String, String> {
    #[cfg(target_os = "linux")]
    let value =
        std::fs::read_to_string("/proc/sys/kernel/random/boot_id").map_err(|e| e.to_string())?;
    #[cfg(target_os = "macos")]
    let value = {
        let output = std::process::Command::new("/usr/sbin/sysctl")
            .args(["-n", "kern.bootsessionuuid"])
            .output()
            .map_err(|e| e.to_string())?;
        if !output.status.success() {
            return Err("kern.bootsessionuuid is unavailable".into());
        }
        String::from_utf8(output.stdout).map_err(|e| e.to_string())?
    };
    let value = value.trim();
    if value.len() != 36 || !value.bytes().all(|c| c.is_ascii_hexdigit() || c == b'-') {
        return Err("OS boot identity is malformed".into());
    }
    Ok(value.to_ascii_lowercase())
}
#[cfg(any(target_os = "linux", target_os = "macos"))]
fn reading() -> Result<serde_json::Value, String> {
    let boot_id = boot_id()?;
    #[cfg(target_os = "linux")]
    let clock = rustix::time::ClockId::Boottime;
    // Darwin documents MONOTONIC as including system sleep. Its frequency
    // undercount still belongs in the caller's qualified error bound.
    // https://github.com/apple-oss-distributions/Libc/blob/main/gen/clock_gettime.3
    #[cfg(target_os = "macos")]
    let clock = rustix::time::ClockId::Monotonic;
    let ts = rustix::time::clock_gettime(clock);
    let ms = i128::from(ts.tv_sec)
        .checked_mul(1000)
        .and_then(|v| v.checked_add(i128::from(ts.tv_nsec) / 1_000_000))
        .ok_or("clock overflow")?;
    if !(0..=9_007_199_254_740_991).contains(&ms) {
        return Err("clock is not an exact JavaScript-safe millisecond value".into());
    }
    if boot_id != self::boot_id()? {
        return Err("OS clock epoch changed during sample".into());
    }
    Ok(
        serde_json::json!({"boot_id":boot_id,"epoch_id":format!("{}:{boot_id}",std::env::consts::OS),"monotonic_ms":ms as u64}),
    )
}
#[cfg(not(any(target_os = "linux", target_os = "macos")))]
fn reading() -> Result<serde_json::Value, String> {
    Err("no qualified suspend-inclusive native clock is implemented for this platform".into())
}
