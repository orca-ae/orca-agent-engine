'use strict';
const wasm = require('./wasm/orca_dogwood.js');
const { spawnSync } = require('node:child_process');
const { readFileSync } = require('node:fs');
const { join } = require('node:path');
const { createHash, randomUUID } = require('node:crypto');
const instance = randomUUID();
let previousClock;
let clockInvalid = false;
function execute(input) {
  const value = JSON.parse(wasm.execute_json(JSON.stringify(input)));
  if (value.error) throw new Error(value.error);
  return value;
}
exports.execute = execute;
exports.validateRule = rule => execute({ op: 'validate', rule });
exports.evaluate = request => execute({ ...request, op: 'evaluate' });
exports.finalizeOutcome = request => execute({ ...request, op: 'finalize_outcome' });
exports.mergeEvents = events => execute({ op: 'merge_events', events });
exports.schemas = () => execute({ op: 'schemas' });
exports.canonicalTool = request => execute({ ...request, op: 'canonical_tool' });
exports.provenance = () => JSON.parse(readFileSync(join(__dirname, 'provenance.json'), 'utf8'));
exports.readClock = () => {
  if (clockInvalid) throw new Error('native clock qualification was invalidated');
  const platform = `${process.platform}-${process.arch}`;
  const provenance = exports.provenance();
  const helper = provenance.clock_helpers?.[platform];
  if (!helper || helper.path !== `bin/${platform}/orca-dogwood-clock`) {
    throw new Error(`qualified native clock helper is absent for ${platform}`);
  }
  const path = join(__dirname, helper.path);
  const digest = createHash('sha256').update(readFileSync(path)).digest('hex');
  if (digest !== helper.sha256) throw new Error('native clock helper checksum mismatch');
  const result = spawnSync(path, [], { encoding: 'utf8', timeout: 3000, maxBuffer: 16384 });
  if (result.error || result.status !== 0) throw new Error(`native clock helper failed: ${result.error?.message ?? result.stderr?.trim() ?? 'unknown'}`);
  const sample = JSON.parse(result.stdout);
  if (typeof sample.boot_id !== 'string' || !sample.boot_id || typeof sample.epoch_id !== 'string' || !sample.epoch_id || !Number.isSafeInteger(sample.monotonic_ms) || sample.monotonic_ms < 0) {
    throw new Error('native clock helper returned an invalid sample');
  }
  if (previousClock && (sample.boot_id !== previousClock.boot_id || sample.epoch_id !== previousClock.epoch_id || sample.monotonic_ms < previousClock.monotonic_ms)) {
    clockInvalid = true;
    throw new Error('native clock boot/monotonic epoch changed');
  }
  previousClock = sample;
  return { ...sample, epoch_id: `${sample.epoch_id}:${instance}` };
};
