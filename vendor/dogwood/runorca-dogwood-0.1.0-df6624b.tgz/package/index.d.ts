export type Verdict = 'allow' | 'ask' | 'deny' | 'abstain';
export interface Rule { kind?: 'dogwood'; policy: string; appliesTo?: 'all_tools'|'mcp_tools'; history?: 'session'|'principal'; mcpManifests?: {server:string;url:string;tools:Record<string,unknown>[]}[] }
export interface Entity {type:'Vault'|'Unattributed'|'Caller'|'Developer'|'Agent'|'Gateway'|'Harness'|'Workspace';id:string;attributes?:Record<string,unknown>;parents?:{type:'Workspace';id:string}[]}
export interface PolicyCall {action:string;principal:Entity;resource:Entity;request_id:string;session_id:string;input:Record<string,unknown>;subject?:{kind:string;id:string};mcp?:{server:string;server_host:string}}
export interface PolicyEvent extends PolicyCall {kind:'request'|'response'|'error'|'approval';timestamp_ms:number;guardrail_id?:string;output?:Record<string,unknown>;error_type?:'denied'|'failed'|'interrupted';result?:'allow'|'deny';asked_by?:string;approver?:string}
export interface EvaluationRequest {guardrail_id:string;rule:Rule;now_ms:number;history:PolicyEvent[];call:PolicyCall}
export interface DecidingRule {rule_id:string;description?:string;effect:'permit'|'forbid';ask:boolean}
export interface EvaluationResult {verdict:Verdict;deciding_rules:DecidingRule[];errors:string[];valid_before:number|null;policy_hash:string;events:{allow:PolicyEvent[];deny:PolicyEvent[]}}
export interface OutcomeRequest {guardrail_id:string;rule:Rule;call:PolicyCall;now_ms:number;outcome:'allowed'|'denied'|'response'|'failed'|'interrupted'|'approved'|'refused';output?:unknown;asking_rule_ids?:string[];approver?:string}
export interface OutcomeResult {events:PolicyEvent[];errors:string[];policy_hash:string}
export interface MergedEvents {events:PolicyEvent[];errors:string[]}
export interface ValidationResult {valid:boolean;errors:string[];warnings:string[];stateful:boolean;rule_ids:string[];policy_hash:string;core_version:string;language_version:string}
export function execute(input:Record<string,unknown>):unknown;
export function validateRule(rule:Rule):ValidationResult;
export function evaluate(request:EvaluationRequest):EvaluationResult;
export function finalizeOutcome(request:OutcomeRequest):OutcomeResult;
export function mergeEvents(events:PolicyEvent[]):MergedEvents;
export function schemas():{base_schema:string;event_schemas:{session:string;principal:string};language_version:string;core_version:string;limits:Record<string,number>};
export function canonicalTool(input:{harness:'orca'|'claude_code'|'codex';tool:string;server_url?:string;manifests?:Rule['mcpManifests']}):{action:string;is_mcp:boolean};
export function provenance():Record<string,unknown>;
export function readClock():{boot_id:string;epoch_id:string;monotonic_ms:number};
