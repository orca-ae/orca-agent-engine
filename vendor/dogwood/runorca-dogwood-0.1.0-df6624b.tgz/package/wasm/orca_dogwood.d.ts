/* tslint:disable */
/* eslint-disable */

export function execute_json(input: string): string;
